#/bin/bash
##
##  name:   deploy_seclog_job.sh
##
##  version: 2017-03-03
##
##
##
## another Bob H production
## (c) cellco
##
#set -x 
DIR=`dirname $0`

if [[ -n "$DIR"  ]] ; then
  DIR="$DIR/"
fi


OS=`/bin/uname -s`
VER=`/bin/uname -v`

sourceexecfile=${DIR}seclog_job.sh
targetexecfile=/opt/vzwsec/bin/seclog_job.sh


if [[ ! -f  "$sourceexecfile" ]] ; then
  emsg="The file $sourceexecfile is missing - can not continue"
  echo $emsg
  echo "exiting..."
  exit
fi

for mydir in /opt/vzwsec /opt/vzwsec/bin
  do
  if [[ ! -d "$mydir" ]] ; then
    mkdir "$mydir"
  fi
  if [[ ! -d "$mydir" ]] ; then
    emsg="Unable to create the missing directory $mydir - can not continue"
    echo $emsg
    echo "exiting..."
    exit
  fi
  done 

cp $sourceexecfile $targetexecfile
if [[ ! -f "$targetexecfile" ]] ; then
   emsg="Unable to copy $sourceexecfile to $targetexecfile  - can not continue"
   echo $emsg
   echo "exiting..."
   exit
else
  emsg="Copyed in $targetexecfile"
  echo $emsg
fi

if [[ $OS == "SunOS" ]] ; then
  # check if job is already in cron
  wcron=/tmp/mycron.tmp
  if [[ -f $wcron ]] ; then
    rm -f $cron
  fi
  
  crontab -l > $wcron
  RETURN_CODE=$?
  if (( $RETURN_CODE>0 )) ; then
     echo "The crontab command did not return a good exit code. "
     echo "  This script will not be able to modify the cron."
     echo "  This script has failed: exiting"
     exit
  fi 

  if [[ ! -f $wcron ]] ; then
    echo "Unable to create the work file $wcron to manage the cron"
     echo "  This script will not be able to modify the cron."
     echo "  This script has failed: exiting"
     exit
  fi

  isitthere=`grep $targetexecfile $wcron`
  if [[ -n "$isitthere" ]] ; then
    echo "The $targetexecfile already has a cron entry" 
    echo "  It will be replaced." 
    grep -v $targetexecfile $wcron > $wcron.0
  else 
    cp $wcron $wcron.0
  fi

  if [[ ! -f "$wcron.0" ]] ; then
    echo "Unable to create the work file $wcron.0 to manage the cron"
    echo "  This script will not be able to modify the crontab."
    echo "  This script has failed: exiting"
    exit
  fi
  #  -- field format for the cron entries
  #          minute (0-59),
  #          hour (0-23),
  #          day of the month (1-31),
  #          month of the year (1-12),
  #          day of the week (0-6 with 0=Sunday).

  # time data to build cron entry
  #DOW=`date '+%u'`
  #HOD=`date '+%H'`
  MOH=`date '+%M'`

  nullittag='> /dev/null 2>&1'
  cronline="$MOH * * * * $targetexecfile  $nullittag"

  echo "Adding this line to the top of the crontab"
  echo "   $cronline"
  
  echo "$cronline" > $wcron.1
  cat $wcron.0 >> $wcron.1

  if [[ ! -f "$wcron.1" ]] ; then
    echo "Unable to create the work file $wcron.1 to manage the cron"
    echo "  This script will not be able to modify the crontab."
    echo "  This script has failed: exiting"
    exit
  fi

  isittherenow=`grep $targetexecfile $wcron.1`
  if [[ -z "$isittherenow" ]] ; then
    echo "Unable to add the new cron line to the work file $wcron.1 to manage the crontab"
    echo "  This script will not be able to modify the cron."
    echo "  This script has failed: exiting"
    exit
  fi

  crontab $wcron.1
  RETURN_CODE=$?
  if (( $RETURN_CODE>0 )) ; then
     echo "The crontab command did not return a good exit code. "
     echo "  This script will not be able to modify the cron with the contents of $wcron.1"
     echo "  Attemping to restore the orginal cron file $wcron."
     crontab $wcron
     RETURN_CODE=$?
     if (( $RETURN_CODE>0 )) ; then
       echo "The crontab command did not return a good exit code. "
       echo "  This script will not be able to restore the crontab."
       echo "  Manual intervention is required. Please check the cron."
     else
       echo "The crontab command returned a good exit code."
       echo "  This script was able to restore the cron."
       echo "  Please check the cron."
     fi
  else
    echo "The crontab command returned a good exit code."
    echo " This script was able to modify the cron with the contents of $wcron.1"
    echo " This is a correct outcome."

    echo "Running $targetexecfile"
    $targetexecfile
  fi 

 

elif [[ $OS == "Linux" ]] ; then
  #for  linux
  #echo "Linux is handled by an rpm"
  cjob=/etc/cron.hourly/log5stat
  if [[ ! -f "$cjob" ]] ; then
     echo "Creating cron.hourly job log5stat"
  else
     echo "Refreshing cron.hourly job log5tat"
  fi
  cat <<EOF > $cjob
#!/bin/sh

$targetexecfile
EXITVALUE=\$?
if [ \$EXITVALUE != 0 ]; then
    /usr/bin/logger -t log5stat "ALERT exited abnormally with [\$EXITVALUE]"
fi
exit 0
EOF

  if [[ ! -f "$cjob" ]] ; then
    echo "Unable to create $cjob."
    echo "  This script failed."
    echo "  exiting."
    exit
  fi
  chmod 766 $cjob
  RETURN_CODE=$?
  if (( $RETURN_CODE>0 )) ; then
     echo "The chmod command did not return a good exit code. "
     echo "  This script was not able to set the execute perm on $cjob"
     echo "  This script failed."
     echo "  exiting."
     exit
  fi
  correctsum=4182424672
  CSUM=`cksum $cjob | cut -f1 -d" "`

  if [[ "$CSUM" != "$correctsum" ]] ; then
    echo "The cksum of the $cjob file is wrong."
     echo "  This script was not able to correctly install the $cjob"
     echo "  This script failed."
     echo "  exiting."
     exit
  else
    echo "The $cjob appears to be correctly installed."
    echo "  Successful completion"
    echo "  This is a correct outcome."
    echo "Running $targetexecfile"
    $targetexecfile
    exit
  fi

fi


  exit
fi
#EOF
