#!/bin/bash
##
##  name:   stat_job.sh
##
##  version: 2017-12-12 1a
##
##
## another Bob H production
## (c) cellco
##
DIR=`dirname $0`

if [[ -n "$DIR" && "$DIR" != "." ]] ; then
  DIR="$DIR/"
fi


OS=`/bin/uname -s`
VER=`/bin/uname -v`

if [[ $OS = "SunOS" ]] ; then
  release=`/bin/uname -r`
  if [[ "$release" = "5.10" ]] ; then
    useopencsw=true
    NC="/opt/csw/bin/nc"
  elif [[ "$release" = "5.11"  ]] ; then
    NC=/usr/bin/nc
  else
   echo "$release is not supported"
  fi
elif [[ $OS = "Linux" ]] ; then
  #for  linux
  #echo "Linux is handled by an rpm"
  NC=/usr/bin/nc
fi

if [[ ! -f "$NC" ]]; then
  echo  "This script requires netcat $NC to function."
  echo "  We can not proceed with the automated evaluation of the secure loghost parameter."
  if [[ "$useopencsw" == "true" ]] ; then
    echo "  You should be able to install netcat with this command: /opt/csw/bin/pkgutil -i netcat"
  fi
  echo "  exiting...."
  exit
fi
CHOST=nj51rhsp1v.nss.vzwnet.com
SHOST=nj51rhsp1v

#IPSTOTEST=`dig +short ANY  $CHOST`

AREC=`dig +short A $CHOST | tail -1`

RETURN_CODE=$?
if (( $RETURN_CODE>0 )) ; then
   echo "The dig command did not return a good exit code. "
   echo "  This script was not able to find the A rec IPs of $chost"
   echo "  This script failed."
   echo "  exiting."
   exit
fi

AAAAREC=`dig +short AAAA $CHOST | tail -1`

if (( $RETURN_CODE>0 )) ; then
   echo "The dig command did not return a good exit code. "
   echo "  This script was not able to find the AAAA IPs of $chost"
   echo "  This script failed."
   echo "  exiting."
   exit
fi


WORKINGIP=""
port=443
IPSTOTEST="$AREC $AAAAREC"
for ip in $IPSTOTEST
  do
  if [[ "$useopencsw" == "true" ]] ; then
    $NC -z -w 1 $ip $port
    NC_RETURN_CODE=$?
  else 
    echo get | $NC -w 1 $ip $port 
    NC_RETURN_CODE=$?
  fi
  if (( $NC_RETURN_CODE==0 )) ; then
     #echo "$ip worked" 
     WORKINGIP=$ip
     break
  fi
  done

if [[ -z "$WORKINGIP" ]] ; then
  echo "Could not connect to any IP of $CHOST" 
  echo "  This script failed."
  echo "  exiting."
  exit
fi

if [[ "$WORKINGIP" =~ ^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$ ]]; then
   #echo "IPv4 : $WORKINGIP"
   IPTYPE=4
elif [[ "$WORKINGIP"  =~ ^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))$ ]]; then
   #echo "IPv6 : $WORKINGIP";
   IPTYPE=6
else
   #echo "IPv6 : $WORKINGIP";
   IPTYPE=UNKNOWN
   echo "Could determine IP type of $CHOST"
   echo "  This script failed."
   echo "  exiting."
   exit
fi

cafile=/opt/vzwsec/etc/stat.pem
if [[ ! -f  "$cafile" ]] ; then
  emsg="The file $cafile is missing - can not continue" 
  echo $emsg
  echo "exiting..."
  logger -p local5.notice "Unable to run CPI-810 stat job: $emsg"
  exit 
fi

if [[ "${IPTYPE}" = "6" ]] ; then
  suffix="-v6"
else
  suffix=""
fi

if [[ $OS = "SunOS" ]] ; then
  /usr/sfw/bin/wget --ca-certificate=$cafile -${IPTYPE} -qO- https://$SHOST/pub/ksdata/update/cpisol${suffix} | bash
elif [[ $OS = "Linux" ]] ; then
  #for  linux
  #echo "Linux is handled by an rpm"
  /usr/bin/wget  --ca-certificate=$cafile  -${IPTYPE} -qO- https://$SHOST/pub/ksdata/update/cpilin${suffix} | bash
  exit
fi
#EOF



