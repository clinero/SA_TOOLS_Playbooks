
##
## rsyslog and stunnel deploy script
##
##  version 1. 
##
##
## 1.2 2015-06-25 added support for solaris 11.2
## 1.2a added support for stunnel for sparc on 11.2
## 1.3 2017-03-06 added in S Hortons fix for Solaris Release
## another Bob H production
## (c) cellco 
##

DIR=`dirname $0`

if [[ -n "$DIR" ]] ; then 
  DIR="$DIR/"
fi 

OS=`/bin/uname -s`
VER=`/bin/uname -v`

if [[ $OS = "SunOS" ]] ; then
  release=`/bin/uname -r`
  if [[ "$release" = "5.10" ]] ; then 
    # for solaris 10
    cp ${DIR}rsyslog.defaults.csw  /etc/opt/csw/default/rsyslog
    if [[ -f /etc/rsyslog.conf ]] ; then
      cp /etc/rsyslog.conf /etc/rsyslog.conf-`date +%T_%Y`
    fi 
    if [[ -f /etc/logadm.conf ]] ; then
      cp /etc/logadm.conf /etc/logadm.conf-`date +%T_%Y`
      sed 's/\/syslog.pid/\/rsyslogd.pid/g' /etc/logadm.conf > /etc/logadm.conf.new
      if [[ -f  /etc/logadm.conf.new ]] ; then
        cp  /etc/logadm.conf.new /etc/logadm.conf
      fi 
    fi
    cp ${DIR}rsyslog.conf.csw  /etc/rsyslog.conf
    tar xvf ${DIR}stunnel.conf.csw.tar 
    svcadm disable svc:/system/system-log:default
    svcadm enable svc:/network/cswrsyslog:default
    svcadm enable   svc:/network/cswstunnel:default 
    svcs svc:/network/cswrsyslog:default
    svcs svc:/network/cswstunnel:default
   elif [[ "$release" = "5.11" ]]  ; then
  #elif [[ "$VER" = "5.11" ]]  ; then
    if [[ -f /etc/rsyslog.conf ]] ; then
      cp /etc/rsyslog.conf /etc/rsyslog.conf-`date +%T_%Y`
    fi
    PTYPE=`/bin/uname -p`
    if [[ "$PTYPE" != "sparc" ]] ; then
      if [ ! -f ${DIR}rsyslog.conf.sol11 ]  ; then  
        echo "rsyslog.conf.sol11 is missing from the working direcotry $DIR"
        echo "halting with no changes made....."
        exit
      fi 
      if [ ! -f ${DIR}sol.rsyslog.certs.tar  ]  ; then
        echo "sol.rsyslog.certs.tar is missing from the working direcotry $DIR"
        echo "halting with no changes made....."
        exit
      fi
      cp ${DIR}rsyslog.conf.sol11  /etc/rsyslog.conf
      chgrp sys /etc/rsyslog.conf
      if [ -d /etc/pki/rsyslog ] ; then
        echo "taring up the existing /etc/pki/rsyslog"
        tar cf rsyslog.cets.tar-`date +%T_%Y` /etc/pki/rsyslog
      fi 
      echo "untaring the rsyslog certs"
      tar xPvf sol.rsyslog.certs.tar
    else 
      if [ ! -f ${DIR}rsyslog.conf.sol11.sparc ]  ; then
        echo "rsyslog.conf.sol11.sparc is missing from the working direcotry $DIR"
        echo "halting with no changes made....."
        exit
      fi

      if [ ! -f ${DIR}stunnel.linux.conf.tar  ]  ; then
        echo "stunnel.linux.conf.tar is missing from the working direcotry $DIR"
        echo "these linux files are used for sol 11.2 sparc - halting with no changes made..."
        exit
      fi
      cp ${DIR}rsyslog.conf.sol11.sparc /etc/rsyslog.conf
      chgrp sys /etc/rsyslog.conf
      if [ -d /etc/stunnel ] ; then
        echo "taring up the existing /etc/stunnel"
        tar cf stunnel.conf.tar-`date +%T_%Y` /etc/stunnel
      fi
      echo "untaring the stunnel config file and certs"
      mydir=`pwd`
      cd /
      tar xvf ${mydir}/stunnel.linux.conf.tar
      echo "enabling stunnel"
      svcadm enable svc:/network/ssl/stunnel:default
      svcs svc:/network/ssl/stunnel:default
    fi

    online=`svcs svc:/system/system-log:default | grep online`
    if [[ -n "$online" ]] ; then
      echo "disabling the default syslog"
      svcadm disable svc:/system/system-log:default
    fi
    echo "enabling rsyslogd"
    svcadm enable svc:/system/system-log:rsyslog
    echo showing status of the two services only rsyslog should be online
    svcs svc:/system/system-log:default svc:/system/system-log:rsyslog
  else
   echo "$release is not supported"
  fi
elif [[ $OS = "Linux" ]] ; then
  #for  linux
  release=`/bin/uname -r`
  if [[ -f /etc/rsyslog.conf ]] ; then 
    cp /etc/rsyslog.conf /etc/rsyslog.conf-`date +%T_%Y`
  fi 
  if [[ -n $release ]] ; then 
    release=`echo $release | awk -F"." '{print $1"."$2}'`
  fi 
  if [[ $release = "2.5" ]] ; then
    cp ${DIR}rsyslog.conf.redhat5  /etc/rsyslog.conf
  else
    cp ${DIR}rsyslog.conf.redhat6  /etc/rsyslog.conf
  fi
    cp ${DIR}rsyslog.init.linux  /etc/init.d/rsyslog
    service syslog off
    chkconfig syslog off
    yum install rsyslog
    chkconfig rsyslog on
    service rsyslog on
    tar xvf  ${DIR}stunnel.linux.conf.tar
    yum install stunnel
    cp  stunnel.init.linux  /etc/init.d/stunnel
    chkconfig stunnel on 
    service stunnel on
fi 
#EOF
