#!/bin/bash

# use this where lsof (for lsof -i tcp:<port>) isn't available

AWK="/usr/bin/awk"
ECHO="/bin/echo"
PARGS="/usr/bin/pargs"
PFILES="/usr/bin/pfiles"
PS="/usr/bin/ps"
SED="/usr/bin/sed"

${PS} -ef | ${SED} '1d' | while read PS_LINE; do
   PS_PID=$( ${ECHO} "${PS_LINE}" | ${AWK} '{print $2}' )
   PS_PROC=$( ${PARGS} ${PS_PID} | ${SED} -n '1p' | ${SED} 's/^[0-9][0-9]*:[    ]*\(.*\)$/\1/' )
   PORT_USAGE=$( ${PFILES} ${PS_PID} | ${AWK} '/AF_INET/ { printf( "\t%s(%s)\n", $3, $5 ) }' )
   if [ "${PORT_USAGE}" != "" ]; then
      ${ECHO} "${PS_PROC} [PID: ${PS_PID}]"
      ${ECHO} "${PORT_USAGE}"
   fi
done

exit 0

