
##
##  name:   fix_auditlog.sol11.sh
##
##  version: 2017-02-23
##
##
##
## another Bob H production
## (c) cellco
##
DIR=`dirname $0`

if [[ -n "$DIR" && "$DIR" != "." ]] ; then
  DIR="$DIR/"
fi


OS=`/bin/uname -s`
VER=`/bin/uname -v`

if [[ $OS = "SunOS" ]] ; then
  release=`/bin/uname -r`
  if [[ "$release" = "5.11"   ]] ; then

    #srulist=`pkg list -af entire | grep 'i--' | cut -f2 -d"-" | awk 'BEGIN {FS="."}{print $4" " $5 " " $6}'`
    #set -x   
    echo "finding SRU level"
    supported=`pkg list -af entire | grep 'i--' | cut -f2 -d"-" | cut -f1 -d" " | \
     awk 'BEGIN {FS="."}
      {
      major=$4
      middle1=$5
      middle2=$6
      minor=$7
      valid="no"
 
    #  print major
    #  print middle1
    #  print middle2 
    #  print minor
    #  print valid
  
     if ( major > 16 ) 
      {
      valid="yes"
      }
     if ( major == 16 )
      {
       if ( middle1 > 0 )
        {
        valid="yes"
        }
       if ( middle1 == 0 )
        {
        if ( middle2 > 3 )
          {
          valid="yes"
          }
        if ( middle2 == 3 )
          {
          if ( minor >=  0 )
            {
            valid="yes"
            }

          }
        } 
      }
      }
    END { print valid }
'`

    disableit=false
    enableit=false
    if [[ "$supported" == "yes" ]] ; then
      echo "The audit facility should be supported by rsyslogd"
    fi

   #supported=no

    auditlogthere=`egrep -e '^audit.*\/var\/log\/auditlog'  /etc/rsyslog.conf`
    auditnonethere=`egrep -e 'audit.none.*@loghost:514'  /etc/rsyslog.conf | egrep -ve '^#'`

    if [[ -n  "$auditlogthere" && -n "$auditnonethere" && "$supported" == "yes" ]] ; then
      echo "The audit facility is already listed in /etc/rsyslog.conf"
      echo "no change was made to /etc/rsyslog.conf"
    fi 
    if [[ ( -n  "$auditlogthere" || -n "$auditnonethere" ) && "$supported" != "yes" ]] ; then
       echo "The audit facility is already listed in /etc/rsyslog.conf"
       echo "But the OS SRU level does not support this facility for rsyslogd"
       echo "This will be diabled"
       disableit=true
    fi

    if [[ -z  "$auditlogthere" && -z "$auditnonethere" && "$supported" == "yes" ]] ; then
      echo "The audit facility not listed in /etc/rsyslog.conf"
       echo "The OS SRU level does support this facility for rsyslogd"
       echo "This will be enabled"
       enableit=true
    fi


   if [[ "$disableit"  == "true" ]] ; then
     replacefile=$DIR/rsyslog.conf.sol.11.2
     action="without the audit"
   fi
   if [[ "$enableit"  == "true" ]] ; then
     replacefile=$DIR/rsyslog.conf.sol.11.3
     action="with the audit"
   fi

   if [[ "$disableit"  == "true" || "$enableit"  == "true" ]] ; then
     if [[ ! -f "$replacefile" ]] ; then
       echo "The replacement rsyslog config file was not found"
       echo " Can not access $replacefile"
       echo "  This script has failed: exiting"
       exit
     fi
     backupfile=/etc/rsyslog.conf-`date +%T_%Y`
     cp /etc/rsyslog.conf $backupfile
     if [[ !  -f "$backupfile" ]] ; then
       echo "Unable to make a backup copy of the rsyslog.conf file"
       echo "  The copy of /etc/rsyslog.conf to $backupfile failed"
       echo "  This script has failed: exiting"
       exit
     fi
     echo "A backup $backupfile was created of the rsyslog.conf file"

     echo "Deploying the rsyslog.conf $action facility"
     cp $replacefile /etc/rsyslog.conf 

     diff $replacefile /etc/rsyslog.conf 2>&1 >/dev/null
     RETURN_CODE=$?
     if (( $RETURN_CODE>0 )) ; then
       echo "The /etc/rsyslog.conf file is not the same as $replacefile"
       echo "  The copy of $replacefile to /etc/rsyslog.conf failed"
       echo "  This script has failed: exiting"
       exit
     else
      echo "A new /etc/rsyslog.conf file has been installed"
    fi 
   fi


   if [[ "$supported" == "yes" ]] ; then
     echo "Validating audit_syslog plugin settings to enable the pluging"
     auditconfig -setplugin audit_syslog active p_flags=lo,+as,-ss
     audit -s
   else
     echo "Validating audit_syslog plugin settings to disable the pluging"
     auditconfig -setplugin audit_syslog inactive
     audit -s
   fi
   echo "restarting rsyslogd"
   svcadm restart    svc:/system/system-log:rsyslog

cat <<EOF
   Please check the following  
     /var/log/syslog to ensure that rsyslog is was able to read the config file

     netstat -an | grep 10514    to validate that a connection is up to the secloghost
                                 some locatons may need to change the secloghost to securelog in rsyslog.conf

EOF
    
   
  

  else
   echo "$release is not supported by this script, this is for solaris 5.11"
  fi
elif [[ $OS = "Linux" ]] ; then
  #for  linux
  echo "Linux is handled by an rpm"
  exit
fi
#EOF



