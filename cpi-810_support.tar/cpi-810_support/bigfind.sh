

##
##
## find the compliers 
##
##  gnat is ada
##  fpc is pascal
##  f77 is fortan
##  Xcc is cee
##

for f in `find / -type f -print 2>/dev/null | egrep "(acc|gcc|cc|cpp|f77|fpc|gnat|CC|CPP)$"`
do
  file=`basename $f`
  if [[ $file == *\.* ]] ; then
    continue 
  else
    echo $f 
  fi 
done

