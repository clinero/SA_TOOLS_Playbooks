#!/bin/bash
##
##  name:   fix_cron_pam.sh
##
##  version: 2017-02-16 
##
##  
##
## another Bob H production
## (c) cellco 
##

DIR=`dirname $0`

if [[ -n "$DIR" ]] ; then 
  DIR="$DIR/"
fi 

OS=`/bin/uname -s`
VER=`/bin/uname -v`

if [[ $OS = "SunOS" ]] ; then
  release=`/bin/uname -r`
  if [[ "$release" = "5.10" || "$release" = "5.11"  ]] ; then 
    # 
    pamconf=/etc/pam.conf
    if [[ ! -f $pamconf ]] ; then
      echo "no changes have been made"
      echo "  bailing since /etc/pam.conf was not found ....."
      exit
    else
       newpamconf=false
       pamconfgood=false
       pamconf1=/etc/pam.conf
       pam_list_there=`egrep -e 'cron.*account.*pam_list' $pamconf|grep cron.allow | egrep -ve '^#'` 
       if [[ -n "$pam_list_there" ]] ; then
         pamconfgood=true
         echo "The pam_list module is already listed in $pamconf"
         echo "  This is correct"
       fi 
       if [[ "$pamconfgood" == "false" ]] ; then
         pam_cron_line_count=`egrep -e 'cron.*account.' $pamconf | grep -v pam_list | egrep -cve '^#'`
          if [[ "$pam_cron_line_count" -ne 1 ]] ; then 
            pamconf=/etc/pam.d/cron
            if [[ -f $pamconf ]]  ; then
              pam_cron_line_count=`egrep -e 'pam_user_policy' $pamconf | egrep -cve '^#'`
              if [[ "$pam_cron_line_count" -ne 1 ]] ; then 
                echo "There is not a 1 count of lines in $pamconf or in $pamconf1 for cron and pam_unix_account."
                echo "  We can not proceed with the automated repair of this the pam.conf file." 
                echo "  no changes have been made: exiting...."
                exit
              fi
              pam_list_there=`egrep -e 'account.*pam_list' $pamconf|grep cron.allow | egrep -ve '^#'`
              if [[ -n "$pam_list_there" ]] ; then
                pamconfgood=true
                echo "The pam_list module is already listed in $pamconf"
                echo "  This is correct"
              fi
            fi
          fi
      fi #end check of pamlist already being set

      if [[ ! -f /usr/lib/security/pam_list.so && "$pamconfgood" != "true"  ]] ; then
        echo "The /usr/lib/security/pam_list.so was not found."
        echo "  We can not proceed with the automated repair of this the pam.conf file." 
        echo "  exiting...."
      fi
      if [[ "$pamconfgood" == "false" ]] ; then
        echo "The current $pamconf does not have a pam_list module using cron.allow."
        echo " Building a pam cron file as /tmp/pam.conf.tmp"
         #cp /etc/pam.conf /etc/pam.conf-`date +%T_%Y`
         #sed  '/cron.*account.*pam_unix_account.so.1$/cron account binding pam_list.so.1 debug allow=\/etc\/cron.d\/cron.allow \' /etc/pam.conf > /tmp/pam.conf.tmp
         cat $pamconf | \
awk '
{
if ( $0 !~ /cron.*account.*pam_unix_account.so.1/ && $0 !~ /pam_user_policy.so.1/  )
   {
   print $0
  }
else if ( $0 ~ /cron.*account.*pam_unix_account.so.1/  )
  {
  print "cron account binding pam_list.so.1 debug allow=/etc/cron.d/cron.allow"
  print "cron account required pam_unix_account.so.1"
  }
else if ( $0 ~ /pam_user_policy.so.1/  )
  {
  print "account binding pam_list.so.1 debug allow=/etc/cron.d/cron.allow"
  print "account definitive      pam_user_policy.so.1"
  }
}
'  > /tmp/pam.conf.tmp

         pam_list_there=`egrep -e 'cron.*account.*pam_list|account.*pam_list'  /tmp/pam.conf.tmp | grep cron.allow`
         if [[ -z "$pam_list_there" ]] ; then
            echo "The pam_list module was not correctly added to the new tmp pam.conf file."
            echo "  This script has failed."
            echo "  no changes have been made: exiting...."
            exit
         fi
         newpamconf=true
      fi #end check of pamlist already being set
    fi # end check of pam.conf existing 
    missingone=false

    if [[ -f /etc/cron.d/cron.allow ]] ; then
      for i in `ls /var/spool/cron/crontabs`
        do
        if [[ $i =~ '.au' ]] ; then
          continue
        fi
        isthere=`grep $i /etc/cron.d/cron.allow`
        if [[ -z "$isthere" ]] ; then
           goodcronallow=true
           missingone=true
           echo "$i has a cron tab but is not listed in /etc/cron.d/cron.allow"
           echo "  You may need to add $i to the cron.allow file."
           echo "  Do not add normal user accounts to cron.allow."      
           echo '  Only aproved functional (applications) may have crons.'
        fi
        done
      if [[ "$missingone" == "false" ]] ; then
        goodcronallow=true
        echo "The cron.allow file has all the crons listed in it." 
        echo "  This is correct."
        echo '  Only aproved functional (applications) may have crons.'
        echo '  You need to validate that accounts in cron.allow should have crons rights.'
      fi
    else
      echo "There is no existing cron.allow file."
      newcronallow=false
      echo "  Adding the existing cron jobs for local accounts to the cron.allow file."
      rejected=""
      for i in `ls /var/spool/cron/crontabs`
        do
        isthere=`grep $i: /etc/passwd`
        if [[ -n "$isthere" ]] ; then
           echo $i >> /etc/cron.d/cron.allow
        else
          rejected="$i $rejected" 
        fi
        done
      
      if [[ -n "$rejected" ]] ; then
        echo "These crons were rejected: $rejected"
      fi 
      if [[ -f /etc/cron.d/cron.allow ]] ; then 
        newcronallow=true
        goodcronallow=ture
        echo "This is the current cron.allow file that was created."
        cat /etc/cron.d/cron.allow
        echo "  You need to validate that these users need cron access."
        echo '  Only aproved functional (applications) may have crons.'
      fi
    fi

    if [[ "$pamconfgood" = "true" && "$goodcronallow" = "true" ]] ; then 
        echo "No change is required as the pam config for cron has the list module" 
        echo "   and the system already had a cron.allow file" 
        echo "   no changes are required: exiting...."
        exit
    fi 

    if [[ "$newpamconf" = "true"  ]] ; then 
       backupfile=$pamconf-`date +%T_%Y`
       cp $pamconf $backupfile
       if [[ !  -f "$backupfile" ]] ; then 
          echo "Unable to make a backup copy of the $pamconf file"
          echo "  The copy of $pamconf to $backupfile failed" 
          echo "  This script has failed: exiting"
          exit
       fi
       echo "A backup $backupfile was created of the pam stack"
       cp /tmp/pam.conf.tmp $pamconf
       diff /tmp/pam.conf.tmp $pamconf 2>&1 >/dev/null
       RETURN_CODE=$?
       if (( $RETURN_CODE>0 )) ; then
         echo "The $pamconf file is not the same as /tmp/pam.conf.tmp"
         echo "  The copy of /tmp/pam.conf.tmp to $pamconf failed" 
         echo "  This script has failed: exiting"
         exit
       else
         echo "The new $pamconf has been installed"
         echo "  PLEASE: Make sure you can log on this server before ending this session."
         echo "  Make sure that the crons still work"
         echo "  Successful completion"
       fi
    elif [[ "$goodcronallow" = "true" && "$newcronallow" = "true" ]] ; then
       echo "The PAM config was not changed, but a new cron.allow file was made." 
       echo "  Make sure that the crons still work" 
       echo "  Successful completion"
    fi


    else
   echo "$release is not supported"
  fi
elif [[ $OS = "Linux" ]] ; then
  #for  linux
  #echo "Linux is handled by an rpm"
  pamconf=/etc/pam.d/crond
  if [[ ! -f $pamconf ]] ; then
    echo "no changes have been made"
    echo "  bailing since /etc/pam.conf was not found ....."
    exit
  else
    newpamconf=false
    pamconfgood=false
    pam_succeed_there=`egrep -e 'account.*pam_succeed_if.*service.*quiet.*use_uid$' $pamconf| egrep -ve '^#'`
    if [[ -n "$pam_succeed_there" ]] ; then
         pamconfgood=true
         echo "The pam__succeed_if  module is already listed in $pamconf"
         echo "  This is correct"
    else

      pam_unix_there=`egrep -e 'account.*required.*.pam_unix.*' $pamconf| egrep -ve '^#'`
      fixfile=""
      if [[ -n "$pam_unix_there" ]] ; then
         fixfile=$pamconf
      else
        # now we have to deal with include files
        checkfile=/etc/pam.d/crond
        includefiles=""
        includes=$checkfile
        while [[ -n $checkfile ]] 
          do
          for cfile in $includes
            do
            if [[ ! "$cfile" =~ /\etc\/ ]] ; then
              cfile="/etc/pam.d/$cfile"
            fi
            anyincludes=`grep -e 'account.*include.*' $cfile`
            if [[ -n "$anyincludes" ]] ; then
              includes=`cat $cfile | \
              awk '
              {
              if ( $1 ~ /account/ && $2 ~ /include/ ) { print $3 }
              }'`
              includefiles="$includes $includefiles"
            else
              checkfile=""
            fi
          done
          
        done
        #echo $includefiles
        for myfile in $includefiles
          do 
          if [[ ! "$myfile" =~ /\etc\/ ]] ; then
             myfile="/etc/pam.d/$myfile"
          fi

          pam_succeed_there=`egrep -e 'account.*pam_succeed_if.*service.*quiet.*use_uid$' $myfile| egrep -ve '^#'`
          if [[ -n "$pam_succeed_there" ]] ; then
             pamconfgood=true
             echo "The pam__succeed_if  module is already listed in $cfile"
             echo "  This is correct"
             break
          fi
          pam_unix_there=`egrep -e 'account.*required.*.pam_unix.*' $myfile| egrep -ve '^#'`
          fixfile=""
          if [[ -n "$pam_unix_there" ]] ; then
            fixfile="$myfile $fixfile"
          fi


          done
      fi # end else pam_unix_there
    fi # end else 
    if [[ "$pamconfgood" != "true" ]] ; then
      if [[ -n "$fixfile" ]] ; then
        echo "We need to fix file $fixfile"
        for tfile in $fixfile
          do
          echo "The current $tfile does not have a pam_succeed_if module for cron."
          echo "  Building a pam cron file as /tmp/pam.conf.tmp"

          if [[ -h $tfile ]] ; then
            echo "The $tfile is a symlink"
            tfile=`readlink -f $tfile`
            echo "  using $tfile as the target."
          fi

          cat $tfile | \
          awk ' 
          {
          if ( $0 !~ /account.*required.*.pam_unix.*/  )
            {
            print $0
            } 
          else 
            {
            print "account  [success=1 default=ignore] pam_succeed_if.so service in crond quiet use_uid"
            print $0
            }
          }'  > /tmp/pam.conf.tmp
          pam_succeed_there=`egrep -e 'account.*pam_succeed_if.*service.*quiet.*use_uid$' /tmp/pam.conf.tmp| egrep -ve '^#'`
          if [[ -z "$pam_succeed_there" ]] ; then
            echo "The pam_succeed_if module was not correctly added to the new tmp pam.conf file."
            echo "  This script has failed."
            echo "  no changes have been made: exiting...."
            exit
          fi
          backupfile=$tfile-`date +%T_%Y`
          cp $tfile $backupfile
          if [[ !  -f "$backupfile" ]] ; then
            echo "Unable to make a backup copy of the $tfile file"
            echo "  The copy of $tfile to $backupfile failed"
            echo "  This script has failed: exiting"
            exit
          fi
          echo "A backup $backupfile was created of the pam stack file $tfile"
          cp /tmp/pam.conf.tmp $tfile
          diff /tmp/pam.conf.tmp $tfile 2>&1 >/dev/null
          RETURN_CODE=$?
          if (( $RETURN_CODE>0 )) ; then
            echo "The $tfile file is not the same as /tmp/pam.conf.tmp"
            echo "  The copy of /tmp/pam.conf.tmp to $tfile failed"
            echo "  This script has failed: exiting"
            exit
          else
            echo "The new $tfile has been installed"
            echo "  PLEASE: Make sure you can log on this server before ending this session."
            echo "  Make sure that the crons still work"
            echo "  Successful completion"
          fi

          done

      else
        echo "we have no potatoes"
      fi
      #echo hi
  fi
  #echo jaws
  fi
  
 missingone=false

  if [[ -f /etc/cron.allow ]] ; then
    for i in `ls /var/spool/cron`
      do
      if [[ $i =~ '.au' ]] ; then
          continue
      fi
      isthere=`grep $i /etc/cron.allow`
      if [[ -z "$isthere" ]] ; then
         goodcronallow=true
         missingone=true
         echo "$i has a cron tab but is not listed in /etc/cron.d/cron.allow"
         echo "  You may need to add $i to the cron.allow file."
         echo "  Do not add normal user accounts to cron.allow."
         echo '  Only aproved functional (applications) may have crons.'
     fi
     done
     if [[ "$missingone" == "false" ]] ; then
        goodcronallow=true
        echo "The cron.allow file has all the crons listed in it."
        echo "  This is correct."
        echo '  Only aproved functional (applications) may have crons.'
        echo '  You need to validate that accounts in cron.allow should have crons rights.'
      fi

  fi
  exit
fi 
#EOF
