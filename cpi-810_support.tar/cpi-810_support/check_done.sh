#!/bin/bash

##
##
##  check_done.sh
##
##     by                :  Bob Harvey
##     incept date       :  2014/09/17
##
##           version     : 2014/12/17
## 20141216  missing bart check 
## 20141217  missing bart check 

if [[ -n $BASH ]] ; then 
  shellgame=`basename $BASH`  
fi

if [[ $shellgame != bash ]] ; then
  echo "this only can be ran on system with bash"
  echo bailing
  exit
fi 


OS=`/bin/uname -s`


currentns=`grep passwd /etc/nsswitch.conf |  grep -v '^#'`


listcontains() {
  for word in $1; do
    [[ $word = $2 ]] && return 0
  done
  return 1
}


if [ $OS = "Linux" ]; then
  echo "this is for solaris only"
  exit
  ID=/usr/bin/id
else
  ID=/usr/xpg4/bin/id

fi

if [ `$ID -u` != 0 ]; then
  echo This can only be ran by a root account
  echo bagging it
  exit
fi


checkcent ()
{
  majorversion=`adinfo -v | cut -f3 -d" "| cut -f1 -d"."`
  if [[ -z "$majorversion" ]] ; then
    echo "failed: could not determine centify version"
    return 1
  fi
  if [[ "$majorversion" -lt 5 ]] ; then
    echo "failed: centrify version is less than 5"
    return 1
  fi 
  fullzone=`adinfo --zone`
  if [[ -z "$fullzone" ]] ; then
    echo "failed: could not determine centify zone"
    return 1
  fi
  zone=`echo $fullzone | cut -f4 -d"/"`
  if [[ -z "$zone" ]] ; then
    echo "failed: could not determine centify zone from adinfo --zone"
    echo "   the value returned does not comply with the standard"
    return 1
  fi
  if [[ "$zone"  != "NSS Master" ]] ; then
    echo "failed: this system is joined to a non directional centrify zone"
    return 1
  fi 
  utest=`adquery user aharvero`
  if [[ -z "$utest" ]] ; then
    echo "failed: this system is unable to query for a centrify zone user"
    return 1
  fi  
}


getprofilename ()
{

  lcode=`uname -n | awk '{print substr($0,0,4)}'`
  scode=`uname -n | awk '{print substr($0,0,2)}'`

    case  $lcode in
      njbb ) area=njbb;;
      nj51 ) area=nj51;;
      njbd ) area=njbd;;
      cawc ) area=cawc;;
      caro ) area=caro;;
      cosp ) area=cosp;;
      vacu ) area=vacu;;
      casc )  area=casc;;
    esac
  if [ -z "$area" ] ; then
    case $scode in
       ct|ev|il|in|ky|ma|md|mi|nh|nj|ny|oh|pa|pe|ri|va|wi ) area=njbb;;
       de|wv|vt|me|dc ) area=njbb;;
        #nj|ny|pa|de|va|wv|oh|mi|ny|vt|nh|me|ma|ri|ct|dc ) area=njbb;;
       al|ar|fl|ga|la|nc|sc|se|tn|tx ) area=txsl;;
        #tx|tn|nd|sd|ne|ks|ok|nm|mo|ar|la|wi|il|ky|ms|al|ga|fl|sc|nc ) area=txsl ;;
        az|ca|co|hi|ia|id|ks|mn|mo|mt|nd|ne|nm|nv|or|sd|ut|wa ) area=caro;;
       #ca|wa|az|or|nv|id|nv|ut|mt|wy|nm|hi|ak    ) area=caro;;
       #co          ) area=cosp;;
       *)            area=njbb;;
    esac
  fi

  profileName=${area}-v11-ssl
  echo $profileName

}




checkldap ()
{

connected=`/usr/lib/ldap/ldap_cachemgr -g | grep -c UP`

if [[ "$connected" -lt 1 ]] ; then
    echo "failed: this system is unable to contact any LDAP server"
    return 1
fi


configprofilename=`ldapclient list |grep NS_LDAP_PROFILE |grep ssl |awk '{print $2}'`

#grep passwd /etc/nsswitch.conf | grep -v '^#'
if [[ -z "$configprofilename" ]] ; then
  echo "failed: can not check LDAP profile name"
  return 1
fi

defaultprofilename=`getprofilename`
#echo $defaultprofilename

if [[ -z "$defaultprofilename" ]] ; then
  echo "failed: can not determine the default LDAP profile name"
  return 1
fi

if [[ "$defaultprofilename" != "$configprofilename" ]]; then
  echo "failed: LDAP profile name $configprofilename is wrong should be $defaultprofilename"
  return 1
fi
return 0 
}

checkssh ()
{
if [[ -f /etc/ssh/sshd_config  ]] ; then
   setting=`grep PermitRootLogin  /etc/ssh/sshd_config | grep -v '^#'|awk '{print $2}'`
    if [[ "$setting" != "no" ]] ; then
      echo "failed: sshd check allows root login"
      return
    fi
else
  echo "failed: sshd check  /etc/ssh/sshd_config is missing"
  return
fi
}

checkpolicy ()
{
release=`/bin/uname -r`
if [[ "$release" != "5.10" ]] ; then
    echo "failed: $release is not supported"
    return
fi
myfile=/etc/security/policy.conf 
there=`egrep "^CRYPT_ALGORITHMS_ALLOW=" $myfile | grep -v '^#'`
if [[ -n "$there" ]] ; then
   value=`echo $there | awk '{print $1}'`
   if [[ "$value" != "CRYPT_ALGORITHMS_ALLOW=2a,md5,5,6" ]] ; then
      echo "failed: CRYPT_ALGORITHMS_ALLOW is set wrong in policy.conf"
      return
   fi
else
  echo "failed: CRYPT_ALGORITHMS_ALLOW is not set in policy.conf"
fi

cgood=no
there=`egrep "^CRYPT_DEFAULT=" $myfile | grep -v '^#'`
if [[ -n "$there" ]] ; then
   value=`echo $there | awk '{print $1}'`
   if [[ "$value" = "CRYPT_DEFAULT=6" ]] ; then
      cgood=yes
   fi
   if [[ "$value" = "CRYPT_DEFAULT=2a" ]] ; then
      cgood=yes
   fi
   if [[ "$cgood" = "no" ]] ; then
     echo "failed: CRYPT_DEFAULT is not 2a or 6 in policy.conf"
     return
   fi
else
  echo "failed: CRYPT_DEFAULT is not set in policy.conf"
fi

there=`egrep "^LOCK_AFTER_RETRIES=" $myfile | grep -v '^#'`
if [[ -n "$there" ]] ; then
   value=`echo $there | awk '{print $1}'`
   if [[ "$value" != "LOCK_AFTER_RETRIES=NO" ]] ; then
      echo "failed: LOCK_AFTER_RETRIES is set wrong in policy.conf"
      return
   fi
else
  echo "failed: LOCK_AFTER_RETRIES is not set in policy.conf"
fi

myfile=/etc/default/passwd
there=`egrep "^PASSLENGTH=" $myfile | grep -v '^#'`
if [[ -n "$there" ]] ; then
   value=`echo $there | awk '{print $1}'`
   if [[ "$value" != "PASSLENGTH=8" ]] ; then
      echo "failed: PASSLENGTH is set wrong in /etc/default/passwd"
      return
   fi
else
  echo "failed: PASSLENGTH is not set in /etc/default/passwd"
fi

there=`egrep "^MINALPHA=" $myfile | grep -v '^#'`
if [[ -n "$there" ]] ; then
   value=`echo $there | awk '{print $1}'`
   if [[ "$value" != "MINALPHA=2" ]] ; then
      echo "failed: MINALPHA is set wrong in /etc/default/passwd"
      return
   fi
else
  echo "failed: MINALPHA is not set in /etc/default/passwd"
fi

there=`egrep "^MINSPECIAL=" $myfile | grep -v '^#'`
if [[ -n "$there" ]] ; then
   value=`echo $there | awk '{print $1}'`
   if [[ "$value" != "MINSPECIAL=1" ]] ; then
      echo "failed: MINSPECIAL is set wrong in /etc/default/passwd"
      return
   fi
else
  echo "failed: MINSPECIAL is not set in /etc/default/passwd"
fi


there=`egrep "^MINDIGIT=" $myfile | grep -v '^#'`
if [[ -n "$there" ]] ; then
   value=`echo $there | awk '{print $1}'`
   if [[ "$value" != "MINDIGIT=1" ]] ; then
      echo "failed: MINDIGIT is set wrong in /etc/default/passwd"
      return
   fi
else
  echo "failed: MINDIGIT is not set in /etc/default/passwd"
fi

there=`egrep "^MINUPPER=" $myfile | grep -v '^#'`
if [[ -n "$there" ]] ; then
   value=`echo $there | awk '{print $1}'`
   if [[ "$value" != "MINUPPER=1" ]] ; then
      echo "failed: MINUPPER is set wrong in /etc/default/passwd"
      return
   fi
else
  echo "failed: MINUPPER is not set in /etc/default/passwd"
fi

there=`egrep "^MINLOWER=" $myfile | grep -v '^#'`
if [[ -n "$there" ]] ; then
   value=`echo $there | awk '{print $1}'`
   if [[ "$value" != "MINLOWER=1" ]] ; then
      echo "failed: MINLOWER is set wrong in /etc/default/passwd"
      return
   fi
else
  echo "failed: MINLOWER is not set in /etc/default/passwd"
fi

there=`egrep "^MAXWEEKS=" $myfile | grep -v '^#'`
if [[ -n "$there" ]] ; then
   value=`echo $there | awk '{print $1}'`
   if [[ "$value" != "MAXWEEKS=12" ]] ; then
      echo "failed: MAXWEEKS is set wrong in /etc/default/passwd"
      return
   fi
else
  echo "failed: MAXWEEKS is not set in /etc/default/passwd"
fi

there=`egrep "^MINWEEKS=" $myfile | grep -v '^#'`
if [[ -n "$there" ]] ; then
   value=`echo $there | awk '{print $1}'`
   if [[ "$value" != "MINWEEKS=2" ]] ; then
      echo "failed: MINWEEKS is set wrong in /etc/default/passwd"
      return
   fi
else
  echo "failed: MINWEEKS is not set in /etc/default/passwd"
fi


there=`egrep "^DICTIONLIST=" $myfile | grep -v '^#'`
if [[ -n "$there" ]] ; then
   value=`echo $there | awk '{print $1}'`
   if [[ "$value" != "DICTIONLIST=/usr/share/lib/dict/words" ]] ; then
      echo "failed: DICTIONLIST is set wrong in /etc/default/passwd"
      return
   fi
else
  echo "failed: DICTIONLIST is not set in /etc/default/passwd"
fi


there=`egrep "^DICTIONDBDIR=" $myfile | grep -v '^#'`
if [[ -n "$there" ]] ; then
   value=`echo $there | awk '{print $1}'`
   if [[ "$value" != "DICTIONDBDIR=/var/passwd" ]] ; then
      echo "failed: DICTIONDBDIR is set wrong in /etc/default/passwd"
      return
   fi
else
  echo "failed: DICTIONDBDIR is not set in /etc/default/passwd"
fi

there=`egrep "^NAMECHECK=" $myfile | grep -v '^#'`
if [[ -n "$there" ]] ; then
   value=`echo $there | awk '{print $1}'`
   if [[ "$value" != "NAMECHECK=YES" ]] ; then
      echo "failed: NAMECHECK is set wrong in /etc/default/passwd"
      return
   fi
else
  echo "failed: NAMECHECK is not set in /etc/default/passwd"
fi

there=`egrep "^HISTORY=" $myfile | grep -v '^#'`
if [[ -n "$there" ]] ; then
   value=`echo $there | awk '{print $1}'`
   if [[ "$value" != "HISTORY=5" ]] ; then
      echo "failed: HISTORY is set wrong in /etc/default/passwd"
      return
   fi
else
  echo "failed: HISTORY is not set in /etc/default/passwd"
fi


there=`egrep "^DICTIONMINWORDLENGTH=" $myfile | grep -v '^#'`
if [[ -n "$there" ]] ; then
   value=`echo $there | awk '{print $1}'`
   if [[ "$value" != "DICTIONMINWORDLENGTH=5" ]] ; then
      echo "failed: DICTIONMINWORDLENGTH is set wrong in /etc/default/passwd"
      return
   fi
else
  echo "failed: DICTIONMINWORDLENGTH is not set in /etc/default/passwd"
fi

myfile=/etc/default/login
#there=`egrep "^DISABLETIME=" $myfile | grep -v '^#'`
#if [[ -n "$there" ]] ; then
#   value=`echo $there | awk '{print $1}'`
#   if [[ "$value" != "DISABLETIME=15" ]] ; then
#      echo "failed: DISABLETIME is set wrong in /etc/default/login"
#      return
#   fi
#else
#  echo "failed: DISABLETIME is not set in /etc/default/login"
#fi

there=`egrep "^SYSLOG_FAILED_LOGINS=" $myfile | grep -v '^#'`
if [[ -n "$there" ]] ; then
   value=`echo $there | awk '{print $1}'`
   if [[ "$value" != "SYSLOG_FAILED_LOGINS=0" ]] ; then
      echo "failed: SYSLOG_FAILED_LOGINS is set wrong in /etc/default/login"
      return
   fi
else
  echo "failed: SYSLOG_FAILED_LOGINS is not set in /etc/default/login"
fi

}

checksudo ()
{
there=`pkginfo -l VZWsudo | grep VERSION: |awk '{print $2}'`
if [[ -z "$there" ]] ; then
  echo "failed: missing VZWsudo"
  return
fi

status=`pkginfo -l VZWsudo | grep STATUS: |awk '{print $2}'`
if [[ -z "$status" ]] ; then
  echo "failed: unable to check status of VZWsudo"
  return
fi

if [[ "$status" != "completely" ]] ; then
  echo "failed: status of VZWsudo is not completely installed"
  return
fi


majorversion=`echo $there | cut -f1 -d"."`
minorversion=`echo $there | cut -f2 -d"."`

if [[ -z "$majorversion"  ]] || [[ -z "$minorversion" ]] ; then
  echo "failed: unable to check VZWsudo version"
  return
fi

if  [[ "$majorversion" -lt 2 ]] ; then
  if [[ "$minorversion" -lt 8 ]] ; then
    echo "failed: VZWsudo version check, must be at least 1.8"
    return
  fi 
fi 


if [[  -f  /usr/local/bin/sudo ]] ; then
   if [[ ! -L  /usr/local/bin/sudo ]] ; then
     echo "failed: /usr/local/bin/sudo is not a symlink"
   fi
fi 

if [[  -f  /usr/bin/sudo ]] ; then
   if [[ ! -L  /usr/bin/sudo ]] ; then
     echo "failed: /usr/bin/sudo is not a symlink"
   fi
fi

myfile=/opt/vzwsec/bin/sudo
if [[ ! -f $myfile ]] ; then
   echo "failed: /opt/vzwsec/bin/sudo is missing"
   return
fi

myfile=/opt/vzwsec/etc/sudoers
if [[ -f $myfile ]] ; then
  there=`grep "Defaults" $myfile |grep iolog_dir | grep -v '^#'`
  if [[ -z "$there" ]] ; then
    echo "failed: sudo-io not set in $myfile"
  else
   #Defaults iolog_dir=/var/log/sudo-io
   found=no
   for i in $there
     do
       #echo $i
       if [[ "$i" = "iolog_dir=/var/log/sudo-io" ]] ; then
         found=yes
       fi 
     done
    if [[ "$found" = "no" ]] ; then
      echo "failed: sudo-io not set to /var/log/sudo-io in $myfile"
    fi 
  fi
else
   echo "failed: /opt/vzwsec/etc/sudo is missing"
fi

}

checklogadm ()
{

there=`pkginfo -l VZWlogadm | grep VERSION: |awk '{print $2}'`
if [[ -z "$there" ]] ; then
  echo "failed: missing VZWlogadm"
  return
fi

status=`pkginfo -l VZWlogadm | grep STATUS: |awk '{print $2}'`
if [[ -z "$status" ]] ; then
  echo "failed: unable to check status of VZWlogadm"
  return
fi

if [[ "$status" != "completely" ]] ; then
  echo "failed: status of VZWlogadm is not completely installed"
  return
fi

majorversion=`echo $there | cut -f1 -d"."`
minorversion=`echo $there | cut -f2 -d"."`

if [[ -z "$majorversion"  ]] || [[ -z "$minorversion" ]] ; then
  echo "failed: unable to check VZWlogadm version"
  return
fi

if  [[ "$majorversion" -lt 2 ]] ; then
  if [[ "$minorversion" -lt 1 ]] ; then
    echo "failed: VZWlogadm version check, must be at least 1.1"
    return
  fi
fi

online=`svcs  svc:/application/management/logadm:logadm | grep online`

if [[ -z "$online" ]] ; then
  echo "failed: unable to determine the state of svc:/application/management/logadm:logadm"
  return
fi
groupval=`getent group patrol`
if [[ -z "$groupval" ]] ; then 
  echo "failed: unable to get the NSA patrol group value"
  return
fi 

there=`echo $groupval | grep logadm`

if [[ -z "$there" ]] ; then
  echo "failed: logadm is not in the patrol group"
fi

}

checkrsyslogd ()
{

online=`svcs  svc:/system/system-log:default | grep online`

if [[ -n "$online" ]] ; then
  echo "failed: syslog is online - use rsyslog instead" 
  return
fi

online=`svcs svc:/network/cswrsyslog:default | grep online`

if [[ -z "$online" ]] ; then
  echo "failed: unable to determine the state of svc:/network/cswrsyslog:default"
  return
fi


if [[ ! -f /opt/csw/bin/pkgutil ]] ; then
   echo "failed: /opt/csw/bin/pkgutil is missing - can not check rsyslog"
   return
fi

there=`/opt/csw/bin/pkgutil --list CSWrsyslog`
if [[ -z "$there" ]] ; then
  echo "failed: unable to check CSWrsyslog"
  return
fi

myfile=/etc/rsyslog.conf

if [[ ! -f $myfile ]] ; then
  echo "failed: $myfile is missing - can not check rsyslog"
  return
fi

checklist="auth.debug cron.debug daemon.debug kern.debug lpr.debug mail.debug mark.debug user.debug local0.debug local1.debug local2.debug local3.debug local4.debug local6.debug local7.debug" 

checktarget=`echo $checklist | wc -w`
checkcount=0
for i in $checklist
  do
  there=`grep $i $myfile | grep -v '^#'`
  #echo $there
  for j in $there
   do
   if [[ "$j" = "@secloghost" ]] ; then
     let checkcount=checkcount+1
   fi
   done
  done
if [[ "$checktarget" -gt "$checkcount" ]] ; then
  echo "failed: $myfile is missing facilities with destinations of secloghost  "
fi 

checklist="local0.debug local1.debug local2.debug local3.debug local4.debug local6.debug local7.debug auth.debug cron.debug daemon.debug kern.debug lpr.debug mail.debug mark.debug mark.debug user.debug"

checktarget=`echo $checklist | wc -w`
checkcount=0
for i in $checklist
  do
  there=`grep $i $myfile | grep -v '^#'`
  #echo $there
  for j in $there
   do
   if [[ "$j" = "@loghost" ]] ; then
     let checkcount=checkcount+1
   fi
   done
  done
if [[ "$checktarget" -gt "$checkcount" ]] ; then
  echo "failed: $myfile is missing facilities with destinations of loghost
 "
fi

there=`grep local5.debug $myfile | grep -v '^#'`

if [[ -z "$there" ]] ; then
  echo "failed: rsyslog is not set to send local5.debug to @@localhost:10514"
fi

there=`echo $there | awk '{print $2}'`

if [[ "$there" != "@@localhost:10514" ]]; then
  echo "failed: rsyslog is not set to send local5.debug to @@localhost:10514"
fi

myfile=/etc/opt/csw/default/rsyslog

if [[ ! -f $myfile ]] ; then
  echo "failed: $myfile is missing"
  return
fi

there=`grep /etc/rsyslog.conf $myfile`

if [[ -z "$there" ]] ; then
  echo "failed: the $myfile is missing the SYSLOGD_OPTIONS -c 5 -f /etc/rsyslog.conf"
  return
fi


}

checkstunnel()
{

if [[ ! -f /opt/csw/bin/pkgutil ]] ; then
   echo "failed: /opt/csw/bin/pkgutil is missing - can not check stunnel"
   return
fi

there=`/opt/csw/bin/pkgutil --list CSWstunnel`
if [[ -z "$there" ]] ; then
  echo "failed: unable to check CSWstunnel"
  return
fi


online=`svcs svc:/network/cswstunnel:default | grep online`

if [[ -z "$online" ]] ; then
  echo "failed: unable to determine the state of svc:/network/cswstunnel:default"
  return
fi

fdir=/etc/opt/csw/stunnel
flist="stunnel.conf ca.pem rslclient-cert.pem rslclient-key.pem"
for i in $flist
 do
   if [[ ! -f ${fdir}/${i} ]] ; then
     echo "failed: ${fdir}/${flist} is missing"
     return
   fi
 done

myfile=/etc/opt/csw/stunnel/stunnel.conf
there=`egrep "accept" $myfile | grep -v '^#' | grep localhost:10514`

if [[ -z "$there" ]] ; then
  echo "failed: $myfile is missing accept = localhost:10514"
fi

there=`egrep "connect" $myfile | grep -v '^#' | grep secloghost`

if [[ -z "$there" ]] ; then
  echo "failed: $myfile is missing connect = secloghost:SOMEPORT"
fi

}

checkdns ()
{

tocheck="loghost secloghost sessloghost"

for h in $tocheck
  do
    nslookup $h > /dev/null 2>&1
    RETURN_CODE=$?

    if (( $RETURN_CODE>0 )) ; then
      echo "failed: nslookup of $h"
    fi
  done

}

checkdzdo ()
{
if [[ -f /usr/bin/dzdo ]] ; then
 if  [[ -L /usr/bin/dzdo ]] ; then
   linkto=`ls -l /usr/bin/dzdo| awk '{print $11}'` 
   cenlink=`echo $linkto | grep centrify` 
   if [[ -n "$cenlink" ]] ; then
     echo "failed: dzdo exists as a centrify program"
   fi
 fi
fi

}

checkbart ()
{
myfile=/opt/vzwsec/sbin/nss_bart.bash
if [[ ! -f "$myfile" ]] ; then
 echo "failed: $myfile is missing"
fi

myfile=/var/spool/cron/crontabs/root
if [[ ! -f "$myfile" ]] ; then
  echo "failed: root crontab is missing - can not check bart" 
fi

there=`grep nss_bart.bash $myfile | grep -v '^#'`
if [[ -z "$there" ]] ; then 
  echo "failed: bart job is missing from the root cron"
fi

}

checkaudit ()
{

online=`svcs  svc:/system/auditd:default | grep online`

if [[ -z "$online" ]] ; then
  echo "failed: unable to determine the state of svc:/system/auditd:default"
fi

myfile=/etc/logadm.conf

if [[ ! -f "$myfile" ]] ; then
  echo "failed: $myfile is missing"
else
  there=`grep auditlog $myfile | grep -v '^#'`
  if [[ -z "$there" ]] ; then
    echo "failed: auditlog not listed to rotate in $myfile"
  fi 

fi
}

#check_bart()
#{
#myfile=/opt/vzwsec/sbin/nss_bart.bash
#if [[ ! -f "$myfile" ]] ; then
  #echo "failed: $myfile is missing"
  #return
#fi

#myfile=/var/spool/cron/crontabs/root
#if [[ ! -f "$myfile" ]] ; then
  #echo "failed: $myfile is missing"
  #return
#fi
#there=`grep nss_bart.bash $myfile | grep -v '^#'`
#if [[ -z "$there" ]] ; then
  #echo "failed: bart cron job is missing"
  #return
#fi
#return
#}


checkvzwssh ()
{

online=`/usr/ucb/ps auxww | grep sshd | grep vzwsec `

if [[ -n "$online" ]] ; then
  echo "failed: VZWsshd is running"
fi

}

check_rootsh_enabled()
{
if [ ! -f /var/log/local5log ] ; then
  echo "failed: /var/log/local5log is missing"
  return
fi

there=`tail -200 /var/log/local5log | grep rootsh`

if [ -z "$there" ] ; then
  echo "failed: /var/log/local5log is not being updated"
  return
fi
return
}




checkcentrifysshd ()
{

online=`/usr/ucb/ps auxww | grep sshd | grep centrifydc | grep share`

if [[ -n "$online" ]] ; then
  echo "failed: centrify ssh is running"
fi

}

if [[ $OS = "SunOS" ]] ; then
  if [[ ! -f  /usr/lib/security/pam_list.so ]] ; then
  echo "The pam_list module is mising"
  echo "You many need patch 138219 or 138220 or higher"
  fi
fi

services=`grep passwd /etc/nsswitch.conf | grep -v '^#'`

if [[ -z "$services" ]] ; then
  echo "failed: can not check passwd service"
  exit
fi

isldap=`echo $services | grep ldap`
iscent=`echo $services | grep centrifydc`


checkcentrifysshd
checkvzwssh
checkssh

nss=no
RETURN_CODE=0
if [[ -n $isldap ]] ; then
  service=ldap
  checkldap
  RETURN_CODE=$?
  nss=yes
fi
if [[ -n $iscent ]] ; then
  service=cent
  checkcent
  RETURN_CODE=$?
  nss=yes
fi

if (( $RETURN_CODE>0 )) ; then
  echo  -n "FAILED: Fix the AA service -"
  if [[ -n $isldap ]] ; then
    echo " LDAP service is not working correctly"
  fi
  if [[ -n $iscent ]] ; then
    echo " CentrifyDC service is not working correctly"
  fi
  #exit
fi

if [[ "$nss" = "no" ]] ; then
  "failed: No Valid AA service is listed in nsswitch.conf"
fi


checkpolicy

checksudo
 
checklogadm

checkrsyslogd

checkstunnel

checkdns 

checkdzdo 

checkbart

checkaudit
#check_rootsh_enabled
