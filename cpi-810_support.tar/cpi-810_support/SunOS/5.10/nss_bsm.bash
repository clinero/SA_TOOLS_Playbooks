#!/bin/bash
#

# NSS ENG CPI-810 Compliance, Phase-IA
#   Audit privileged accounts
#
# CRON Entry - Run nightly, ex.
#   00 03 * * * /opt/vzwsec/sbin/nss_bsm.bash

[[ ! -d /var/audit/bsm ]] && exit 1

# Trim local audit files, expectation is audit files are securely
#  archived off-host.
/usr/bin/find /var/audit/bsm -mtime +14 -exec rm -rf {} \;

/usr/sbin/audit -n
