#!/bin/bash
#

# NSS ENG CPI-810 Compliance, Phase-IA
#   Fingerprint system configuration files
#
# CRON Entry - Run nightly, ex.
#   00 03 * * * /opt/vzwsec/sbin/nss_bart.bash

[[ ! -d /var/audit/bart ]] && exit 1
[[ ! -r /opt/vzwsec/etc/bart_rules ]] && exit 1

# Trim local audit files, expectation is audit files are securely
#  archived off-host.
/usr/bin/find /var/audit/bart -mtime +14 -exec rm -rf {} \;

/usr/bin/bart create -r /opt/vzwsec/etc/bart_rules \
    >/var/audit/bart/$(/usr/bin/uname -n)_$(/usr/bin/date '+%FT%T%z').bart
