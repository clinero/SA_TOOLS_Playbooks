#!/usr/bin/bash -p
#

#
# Prepare NSS Solaris 10 server for BSM and BART.
#

# // Project:
# //   NSS ENG - CPI-810 Phase1A
# //   Enable Audit and track changes to system configuration.
# //
# // Summary:
# //    Use the Solaris-provided facility, BART (Basic Audit Reporting
# //   Tool), to perform a file-level fingerprint of important OS
# //   Configuration directories each night.
# //    Use the Solaris-provided facility, BSM (Basic Security Module)
# //   to audit Logins, Logouts, and Administrative Commands executed
# //   by all accounts.
# //
# //    For Phase1A, this feature is enabled only. Centralized collection
# //   and Analysis to be handled later.
# //
# // Assumptions & Dependancies:
# //    System is Solaris 10 update 9 or later and at least 2014q1 patched.
# //    System does not already have BART or BSM enabled.
# //    NSS OpenCSW rsyslogd package installed.
# //
# //    Server will need to be brought down to run level 1 and then rebooted
# //   for auditing to be enabled. Notify Apps and schedule CC.


PATH=/usr/sbin:/usr/bin


function abort
{
    printf "ERROR! : %s\n" "$@"
    exit 1
}

function chk_pkg_sysv
{
    local pkgname=$1

    pkginfo "$pkgname" >/dev/null 2>&1
    [[ "$?" -ne 0 ]] && abort "SYSV Package '"$pkgname"' not installed!"
}

function chk_isfile
{
    [[ ! -f "$1" ]] && abort "File '"$1"' does not exist!"
}

function chk_isdir
{
    [[ ! -d "$1" ]] && abort "Directory '"$1"' does not exist!"
}

function get_ent_count
{
    local mystring="$1"
    local filename="$2"
    local count

    local oldIFS=$IFS
    IFS=$'\n'
    local entArr=( $(grep "${mystring}" "${filename}") )
    count=${#entArr[@]}
    IFS=$oldIFS

    echo $count
}


OSYS=$(uname -s)
OREL=$(uname -r)

STAGING="/opt/vzwsec/stage/cpi-810_support/${OSYS}/${OREL}"

printf "CPI-810 Phase1A Solaris Configuration Change Audit.\n"


#
# Do PreChecks.
#
printf "...Checking Staging and CSWrsyslog dependancy.\n"
chk_isdir	$STAGING
#chk_pkg_sysv	CSWrsyslog
chk_isfile	/etc/rsyslog.conf

#
# Verify (3) auditlog ents for rsyslog.
#  audit.debug   /var/log/auditlog
#  audit.debug   @secloghost
#  audit.debug   @loghost
#
let n=$(get_ent_count audit.debug /etc/rsyslog.conf)
[[ "$n" -ne 3 ]] && abort "Wrong number of audit.debug entries in rsyslog.conf!"


#
# Prepare raw audit files direcory.
#
# TODO:
#    Is Host root filesystem ZFS or UFS?
#        # df -n /
#    If root is ZFS, first remove the OEM system audit directory and
#        create a new ZFS dataset to hold audit files. Continue steps below.
#    # rmdir /var/audit
#    # zfs create -o mountpoint=/var/audit rpool/VAR/audit
# TODAY:
#    Use existing '/var/audit'
#
mkdir -p /var/audit/bsm
mkdir -p /var/audit/bart
chown -R root:root /var/audit
chmod -R 0700 /var/audit


#
# Prepare Logging.
#
touch /var/log/auditlog
chown root:sys /var/log/auditlog
chmod 0600 /var/log/auditlog
logadm -w /var/log/auditlog -C 10 -s 512k -S 10m -c -m 0600 \
    -a 'kill -HUP `cat /var/run/syslog.pid`'


#
# Prepare NSS Audit Scripts plus Crontab.
#
ROOT_CRONTAB="/var/spool/cron/crontabs/root"

mkdir -p /opt/vzwsec/sbin

cfgfile="nss_bart.bash"
cfgtarg="/opt/vzwsec/sbin/${cfgfile}"
cp "${STAGING}/${cfgfile}" "${cfgtarg}"
chown root:root ${cfgtarg}
chmod 0540 ${cfgtarg}

let n=$(get_ent_count "${cfgtarg}" "${ROOT_CRONTAB}")
if [[ $n -eq 0 ]]; then
    printf "00 03 * * * %s\n" ${cfgtarg} >>${ROOT_CRONTAB}
fi

cfgfile="nss_bsm.bash"
cfgtarg="/opt/vzwsec/sbin/${cfgfile}"
cp "${STAGING}/${cfgfile}" "${cfgtarg}"
chown root:root ${cfgtarg}
chmod 0540 ${cfgtarg}

let n=$(get_ent_count "${cfgtarg}" "${ROOT_CRONTAB}")
if [[ $n -eq 0 ]]; then
    printf "00 03 * * * %s\n" ${cfgtarg} >>${ROOT_CRONTAB}
fi


#
# Set NSS BSM Configs.
#
mkdir -p /opt/vzwsec/etc

cfgfile="bart_rules"
cfgtarg="/opt/vzwsec/etc/${cfgfile}"
cp "${STAGING}/${cfgfile}" "${cfgtarg}"
chown root:root ${cfgtarg}
chmod 0440 ${cfgtarg}


cfgfile="audit_startup"
cp "${STAGING}/${cfgfile}" "/etc/security/${cfgfile}"
chown root:sys ${cfgtarg}
chmod 0540 ${cfgtarg}

cfgfile="audit_control"
cp "${STAGING}/${cfgfile}" "/etc/security/${cfgfile}"
chown root:sys ${cfgtarg}
chmod 0440 ${cfgtarg}


#
# Config auditd to use rsyslog now.
#
svccfg -s svc:/system/auditd setprop syslog/entities=svc:/network/cswrsyslog
svcadm refresh svc:/system/auditd

#
# Fin.
#
printf "...Preparation finished.
Note: 'bsmconv' must still be executed at run-level 1 to complete.
"
