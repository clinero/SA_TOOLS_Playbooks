#!/bin/bash

listcontains() {
  for word in $1; do
    [[ $word = $2 ]] && return 0
  done
  return 1
}


blessedusers="patrol bin root daemon daemon sys adm lp uucp nuucp listen gdm webservd svctag unknown nobody noaccess nobody4 plitent smmsp stdsaudi mightor sshd logadm"


for i in `cat /etc/passwd | grep -v /opt/adminhome |  grep -v \^\# | awk '{print $1}'`
do
tuser=`echo $i | cut -f1 -d":"`
 #echo $tuser


if (listcontains  "$blessedusers" $tuser ) ; then
    echo skipping $tuser
    continue
  fi
echo $tuser
 done

