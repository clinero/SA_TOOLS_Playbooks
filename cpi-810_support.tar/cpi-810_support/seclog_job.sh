#!/bin/bash
##
##  name:   seclog_job.sh
##
##  version: 2017-02-25
##
##
## another Bob H production
## (c) cellco
##


OS=`/bin/uname -s`
VER=`/bin/uname -v`

if [[ $OS == "SunOS" ]] ; then
   /usr/bin/logger  -p local5.notice "SYSLOG_QOS_VALIDATION_TEST"
elif [[ $OS == "Linux" ]] ; then
  /usr/bin/logger  -p local5.notice "QOS_VALIDATION_TEST"
fi
#EOF
