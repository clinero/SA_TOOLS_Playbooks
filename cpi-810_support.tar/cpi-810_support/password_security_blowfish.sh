##
## password_security_blowfish.sh 
##
##  
##     version           :  1.3
##     by                :  Bob Harvey
##     incept date       :  2014/09/15

DIR=`dirname $0`

if [[ -n "$DIR" ]] ; then 
  DIR="$DIR/"
fi 

OS=`/bin/uname -s`

if [[ "$OS" = "SunOS" ]] ; then
  release=`/bin/uname -r`
  if [[ "$release" = "5.10" ]] ; then 
    # for solaris 10
    if [[ -f /etc/security/policy.conf  ]] ; then
      cp /etc/security/policy.conf /etc/security/policy.conf-`date +%T_%Y`
      cp /etc/security/policy.conf /tmp/w.policy
      myfile=/tmp/w.policy
      cat /dev/null >> $myfile.1
      there=`egrep "^CRYPT_ALGORITHMS_ALLOW=" $myfile | grep -v '\^\#'`
      if [[ -n "$there" ]] ; then
         #sed 's/^CRYPT_ALGORITHMS_ALLOW.*/CRYPT_ALGORITHMS_ALLOW=2a,md5,5,6/g' $myfile > $myfile.1
         sed 's/^CRYPT_ALGORITHMS_ALLOW.*/CRYPT_ALGORITHMS_ALLOW=2a,md5,5/g' $myfile > $myfile.1
        cp $myfile.1 $myfile
      else
        echo "CRYPT_ALGORITHMS_ALLOW=2a,md5,5" >> $myfile
      fi

      there=`egrep "^CRYPT_DEFAULT=" $myfile | grep -v '\^\#'`
      if [[ -n "$there" ]] ; then
         sed 's/^CRYPT_DEFAULT.*/CRYPT_DEFAULT=2a/g' $myfile > $myfile.1
        cp $myfile.1 $myfile
      else
        echo "CRYPT_DEFAULT=2a" >> $myfile
      fi
      there=`egrep "^LOCK_AFTER_RETRIES=" $myfile | grep -v '\^\#' `
      if [[ -n "$there" ]] ; then
        sed 's/^LOCK_AFTER_RETRIES.*/LOCK_AFTER_RETRIES=NO/g' $myfile > $myfile.1
        cp $myfile.1 $myfile
      else
        echo "LOCK_AFTER_RETRIES=NO" >> $myfile
      fi

    fi 

    if [[ -f /etc/default/passwd ]] ; then
      cp /etc/default/passwd /etc/default/passwd-`date +%T_%Y`
      cp /etc/default/passwd /tmp/w.pass

      myfile=/tmp/w.pass
      cat /dev/null >> $myfile.1

      there=`egrep "^PASSLENGTH" $myfile | grep -v '\^\#'`
      if [[ -n "$there" ]] ; then
         sed 's/^PASSLENGTH.*/PASSLENGTH=8/g' $myfile > $myfile.1
        cp $myfile.1 $myfile
      else
        echo "PASSLENGTH=8" >> $myfile
      fi

     there=`egrep "^DICTIONDBDIR" $myfile | grep -v '\^\#'`

     if [[ -n "$there" ]] ; then
        sed 's/^DICTIONDBDIR/#DICTIONDBDIR/g' $myfile > $myfile.1
        cp $myfile.1 $myfile
     fi

      there=`egrep "^MINALPHA" $myfile | grep -v '\^\#'`
      if [[ -n "$there" ]] ; then
         sed 's/^MINALPHA.*/MINALPHA=2/g' $myfile > $myfile.1
        cp $myfile.1 $myfile
      else
        echo "MINALPHA=2" >> $myfile
      fi

      there=`egrep "^MINSPECIAL" $myfile | grep -v '\^\#'`
      if [[ -n "$there" ]] ; then
         sed 's/^MINSPECIAL.*/MINSPECIAL=1/g' $myfile > $myfile.1
        cp $myfile.1 $myfile
      else
        echo "MINSPECIAL=1" >> $myfile
      fi

      there=`egrep "^MINDIGIT" $myfile | grep -v '\^\#'`
      if [[ -n "$there" ]] ; then
         sed 's/^MINDIGIT.*/MINDIGIT=1/g' $myfile > $myfile.1
        cp $myfile.1 $myfile
      else
        echo "MINDIGIT=1" >> $myfile
      fi

      there=`egrep "^MINUPPER" $myfile | grep -v '\^\#'`
      if [[ -n "$there" ]] ; then
         sed 's/^MINUPPER.*/MINUPPER=1/g' $myfile > $myfile.1
        cp $myfile.1 $myfile
      else
        echo "MINUPPER=1" >> $myfile
      fi

      there=`egrep "^MINLOWER" $myfile | grep -v '\^\#'`
      if [[ -n "$there" ]] ; then
         sed 's/^MINLOWER.*/MINLOWER=1/g' $myfile > $myfile.1
        cp $myfile.1 $myfile
      else
        echo "MINLOWER=1" >> $myfile
      fi

      there=`egrep "^MAXWEEKS" $myfile | grep -v '\^\#'`
      if [[ -n "$there" ]] ; then
         sed 's/^MAXWEEKS.*/MAXWEEKS=12/g' $myfile > $myfile.1
        cp $myfile.1 $myfile
      else
        echo "MAXWEEKS=12" >> $myfile
      fi

      there=`egrep "^MINWEEKS" $myfile | grep -v '\^\#'`
      if [[ -n "$there" ]] ; then
         sed 's/^MINWEEKS.*/MINWEEKS=2/g' $myfile > $myfile.1
        cp $myfile.1 $myfile
      else
        echo "MINWEEKS=2" >> $myfile
      fi

      there=`egrep "^DICTIONLIST" $myfile | grep -v '\^\#'`
      if [[ -n "$there" ]] ; then
         sed 's/^DICTIONLIST.*/DICTIONLIST=\/usr\/share\/lib\/dict\/words/g' $myfile > $myfile.1
        cp $myfile.1 $myfile
      else
        echo "DICTIONLIST=/usr/share/lib/dict/words" >> $myfile
      fi

      there=`egrep "^DICTIONDBDIR" $myfile | grep -v '\^\#'`
      if [[ -n "$there" ]] ; then
         sed 's/^DICTIONDBDIR.*/DICTIONDBDIR=\/var\/passwd/g' $myfile > $myfile.1
        cp $myfile.1 $myfile
      else
        echo "DICTIONDBDIR=/var/passwd" >> $myfile
      fi

      there=`egrep "^NAMECHECK" $myfile | grep -v '\^\#'`
      if [[ -n "$there" ]] ; then
         sed 's/^NAMECHECK.*/NAMECHECK=YES/g' $myfile > $myfile.1
        cp $myfile.1 $myfile
      else
        echo "NAMECHECK=YES" >> $myfile
      fi

      there=`egrep "^HISTORY" $myfile | grep -v '\^\#'`
      if [[ -n "$there" ]] ; then
         sed 's/^HISTORY.*/HISTORY=5/g' $myfile > $myfile.1
        cp $myfile.1 $myfile
      else
        echo "HISTORY=5" >> $myfile
      fi

      there=`egrep "^DICTIONMINWORDLENGTH" $myfile | grep -v '\^\#'`
      if [[ -n "$there" ]] ; then
         sed 's/^DICTIONMINWORDLENGTH.*/DICTIONMINWORDLENGTH=5/g' $myfile > $myfile.1
        cp $myfile.1 $myfile
      else
        echo "DICTIONMINWORDLENGTH=5" >> $myfile
      fi

    fi    
    if [[ -f /etc/default/login ]] ; then
      cp /etc/default/login /tmp/w.login
      myfile=/tmp/w.login
      cat /dev/null >  $myfile.1

      there=`egrep "^DISABLETIME=" $myfile | grep -v '\^\#'`
      if [[ -n "$there" ]] ; then
        sed 's/^DISABLETIME.*/DISABLETIME=15/g' $myfile > $myfile.1
        cp $myfile.1 $myfile
      else
        echo "DISABLETIME=15" >> $myfile
      fi 
      there=`egrep "^RETRIES=" $myfile | grep -v '\^\#'`
      if [[ -n "$there" ]] ; then
        #sed 's/^RETRIES.*/RETRIES=5/g' $myfile
        sed 's/^RETRIES.*/RETRIES=5/g' $myfile > $myfile.1
        cp $myfile.1 $myfile
      else
        echo "RETRIES=5" >> $myfile
      fi 
      there=`egrep "^SYSLOG_FAILED_LOGINS=" $myfile | grep -v '\^\#'`
      if [[ -n "$there" ]] ; then
        sed 's/^SYSLOG_FAILED_LOGINS.*/SYSLOG_FAILED_LOGINS=0/g' $myfile > $myfile.1
        cp $myfile.1 $myfile
      else
        echo "SYSLOG_FAILED_LOGINS=0" >> $myfile
      fi

    fi 

    if [[ -f /tmp/w.pass ]] ; then
      cp /tmp/w.pass /etc/default/passwd
    fi 

    if [[ -f /tmp/w.policy ]] ; then
      cp /tmp/w.policy /etc/security/policy.conf
    fi
    if [[ -f /tmp/w.login ]] ; then
       cp  /tmp/w.login /etc/default/login
    fi 

    mkpwdict
  else
   echo "$release is not supported"
  fi
elif [[ $OS = "Linux" ]] ; then
  #for  linux
  echo "Linux is handled by an rpm"
fi 

