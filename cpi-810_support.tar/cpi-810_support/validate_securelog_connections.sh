#!/bin/bash
##
##  name:   validate_securelog_connections.sh
##
##  version: 2017-03-17
##
##  
##
## another Bob H production
## (c) cellco 
##

DIR=`dirname $0`

if [[ -n "$DIR" ]] ; then 
  DIR="$DIR/"
fi 

scode=`uname -n | awk '{print substr($0,0,2)}'`

if [[ "$scode" == "tx" ]] ; then
  echo "Sorry TX is not supported by this script"
  echo " Please do the configuration of sessloghost into the rsyslog.conf or stunnel file manually"
  echo "  exiting...."
  echo failed >> /tmp/sloghosttests
  exit
fi

lcode=`uname -n | awk '{print substr($0,0,4)}'`

case  $lcode in
      njbb ) area=dce;;
      nj51 ) area=dce;;
      njbd ) area=dce;;
      cawc ) area=dcw;;
      caro ) area=dcw;;
      cosp ) area=dcc;;
      vacu ) area=tme;;
      casc )  area=tmw;;
esac

if [ -z "$area" ] ; then
  case $scode in
     ct|ev|il|in|ky|ma|md|mi|nh|nj|ny|oh|pa|pe|ri|va|wi ) area=dce;;
     de|wv|vt|me|dc ) area=dce;;
     #nj|ny|pa|de|va|wv|oh|mi|ny|vt|nh|me|ma|ri|ct|dc ) area=njbb;;
     al|ar|fl|ga|la|nc|sc|se|tn|tx ) area=dcs;;
     #tx|tn|nd|sd|ne|ks|ok|nm|mo|ar|la|wi|il|ky|ms|al|ga|fl|sc|nc ) area=txsl;;
     az|ca|co|hi|ia|id|ks|mn|mo|mt|nd|ne|nm|nv|or|sd|ut|wa ) area=dcw;;
     #ca|wa|az|or|nv|id|nv|ut|mt|wy|nm|hi|ak    ) area=caro;;
     #co          ) area=cosp;;
     *)            area=dcw;;
  esac
fi


OS=`/bin/uname -s`
VER=`/bin/uname -v`

if [[ $OS = "SunOS" ]] ; then
  release=`/bin/uname -r`
  if [[ "$release" = "5.10" ]] ; then 
    useopencsw=true
    usestunnel=true
    NC=/opt/csw/bin/nc 
  elif [[ "$release" = "5.11"  ]] ; then
    NC=/usr/bin/nc
  else
   echo "$release is not supported"
  fi
elif [[ $OS = "Linux" ]] ; then
  #for  linux
  #echo "Linux is handled by an rpm"
  NC=/usr/bin/nc
fi 

if [[ ! -f "$NC" ]]; then 
  echo  "This script requires netcat $NC to function."
  echo "  We can not proceed with the automated evaluation of the secure loghost parameter."
  if [[ "$usestunnel" == "true" ]] ; then
    echo "  You should be able to install netcat with this command: /opt/csw/bin/pkgutil -i netcat"
  fi
  echo "  exiting...."
  echo failed >> /tmp/sloghosttests
  exit
fi


serachstring=`grep isa.vzwnet.com /etc/resolv.conf | egrep -v  "^#" `
if [[ -z "$serachstring" ]] ; then
  echo "Unable to find the isa area in the seach paramter of the /etc/resolv.conf"
  echo "  We can not proceed with the automated evaluation of the secure loghost parameter."
  echo "  exiting...."
  echo failed >> /tmp/sloghosttests
  exit
fi
#echo found $serachstring


validisalist="dce dcs dcc dcw dce tme tmw dce dcs6 dcc6 dcw6 dce6 tme6 tmw6"

#set -x
for i in $serachstring
do
  #echo value is $i
  if [[ "$i"  =~ \.isa\.vzwnet\.com$ ]] ; then 
     #echo domain is $i
     fistpart=`echo $i | cut -f1 -d"."`
     #echo ISA is $fistpart
     if [[ -z "$fistpart" ]] ; then
       echo "Unable to determine the ISA area from the search order in the resolv.conf"
       echo "  We can not proceed with the automated evaluation of the secure loghost parameter."
       echo "  exiting...."
       echo failed >> /tmp/sloghosttests
       exit
    fi
    validisa=false
    for  mi in $validisalist
      do
      if [[ "$mi" == "$fistpart" ]] ; then
        validisa=true
        break 
      fi
      done
    if [[ "$validisa" == "true" ]] ; then
      echo "Using $i as the ISA domain"
      ISADOMAIN=$i
      break
    else
      echo "Unable to determine the ISA area from the search order in the resolv.conf"
      echo "  We can not proceed with the automated evaluation of the secure loghost parameter."
      echo "  exiting...."
      echo failed >> /tmp/sloghosttests
      exit
    fi
   
  fi 
done

if [[ "$ISADOMAIN" == "$area".isa.vzwnet.com ]] ; then
  echo "The ISA area is set correctly for this system to log to a IPv4 secure log host."
elif  [[ "$ISADOMAIN" == "$area"6.isa.vzwnet.com ]] ; then
  echo "The ISA area is set correctly for this system to log to a IPv6 secure log host."
else
  echo "The ISA area in the resolve.conf search order is not standard for systems with $lcode host names."
  echo "  Systems on internet connected DMZs should be using one of the DMZ ISA domains."
  echo "  But all other systems need to be using thiere correct ISA domain."
fi

sloghost=""

fistone=true
## pefer secureloghost over 
for i in secureloghost secloghost
do 
  dig +short $i.$ISADOMAIN > /dev/null 2>&1
  RETURN_CODE=$?
  if (( $RETURN_CODE==0  )) ; then
    if [[ "$usestunnel" == "true" ]] ; then
      program=stunnel
      port=8888
      echo "Note that is is normal for the stunnel check to take 20 seconds or more."
    else
      program=rsyslog
      port=10514
    fi
    echo "Checking connection to $i.$ISADOMAIN on port $port for $program" 
    if [[ "$useopencsw" == "true" ]] ; then
      $NC -z -w 1 $i $port
      NC_RETURN_CODE=$?
    else
      echo get | $NC -w 1 $i $port
      NC_RETURN_CODE=$?
    fi
    #$NC -w 2  secloghost $port

    #true
    NC_RETURN_CODE=$?
    if (( $NC_RETURN_CODE==0 )) ; then
      echo  "Connection Validated to $i.$ISADOMAIN on port $port"
      sloghost=$i
      break 
    else
      echo "Falied to connection to $i.$ISADOMAIN on port $port."
      exit
    fi
  fi 
  fistone=false
done

if [[ -z "$sloghost" ]] ; then
     echo "Unable to determine the securelog host to use."
     echo "  Could not connect to either secloghost or secureloghost."
     echo "  We can not proceed with the automated evaluation of the secure loghost parameter."
     echo "  exiting...."
     #echo failed >> /tmp/sloghosttests
     exit
fi

if [[ "$fistone" == "false" ]] ; then
  echo "Using secloghost as the securelog host."
  echo " This not the correct solution."
  echo " The secureloghost should be used but netcat was unable to test a connection ot it."
fi


#echo $sloghost >> /tmp/sloghosttests

if [[ "$usestunnel" == "true" ]] ; then
  if [[ $OS = "SunOS" ]] ; then
    stconf=/etc/opt/csw/stunnel/stunnel.conf
  fi
  connectto=`egrep -v  "^#|^\;"   $stconf | grep connect`
  if [[ -z "$connectto" ]] ; then
     echo "Unable to determine the connect parameter in the $stconf"
     echo "  We can not proceed with the automated correction of this parameter."
     echo "  You need to do this manually"
     echo "  exiting...."
     exit
  fi
  hostinconnecto=`echo $connectto | cut -f2 -d"=" | cut -f1 -d":"| xargs`
  if [[ -z "$hostinconnecto" ]] ; then
     echo "Unable to determine the connect host value in the $stconf"
     echo "  We can not proceed with the automated correction of this parameter."
     echo "  You need to do this manually"
     echo "  exiting...."
     exit
  fi

  if [[ "$hostinconnecto" == "$sloghost" ]] ; then
    echo "The host value in $stconf is correcly set to $hostinconnecto."
    echo "  No changes are needed."
    echo "  exiting...."
    exit
  else
    echo "The host value in $stconf is not set to $sloghost."
    echo " It is currenlty set $hostinconnecto"
    echo " Changing this value now from $hostinconnecto to $sloghost."
    backupfile=$stconf-`date +%T_%Y`
    cp $stconf $backupfile
    if [[ !  -f "$backupfile" ]] ; then
      echo "Unable to make a backup copy of the $stconf file"
      echo "  The copy of $stconf to $backupfile failed"
      echo "  This script has failed: exiting"
      exit
    fi
    echo "A backup $backupfile was created of the stunnel config"
    tmpfile=/tmp/stunnel.conf.tmp
    sed "s/$hostinconnecto:8888/ $sloghost:8888/g" $stconf  > $tmpfile
    if [[ ! -f $tmpfile ]] ; then
      echo "Unable to make a temp working file $tmpfile"
      echo "  This script has failed: exiting"
      exit
    fi
    isthere=`grep $sloghost $tmpfile`
    if [[ -z "$isthere" ]] ; then
      echo "Unable to created $tmpfile does not containt $sloghost"
      echo "  This script has failed: exiting"
      exit
    fi
    cp $tmpfile $stconf
    diff $tmpfile $stconf  2>&1 >/dev/null
    RETURN_CODE=$?
    if (( $RETURN_CODE>0 )) ; then
      echo "The $tmpfile file is not the same as $stconf"
      echo "  The copy of $tmpfile to $stconf failed"
      echo "  This script has failed: exiting"
      exit
    else
      echo "The new $stconf has been installed"
      echo "  restarting stunnel"
      svcadm  restart  svc:/network/cswstunnel:default
      echo "  sleeping 3"
      sleep 3 
      echo "  running svcs svc:/network/cswstunnel:default"
      svcs svc:/network/cswstunnel:default
      isonlines=`svcs svc:/network/cswstunnel:default | grep online`
      if [[ -n "$isonlines" ]] ; then
        echo "  Successful completion"
        exit
      else
        echo "  The stunnel service is not online."
        echo "  This script has failed: exiting"
        exit
      fi
    fi
  fi
else
  # not using stunnel
  sconf=/etc/rsyslog.conf
  connectto=`grep 'local5.*:10514' $sconf | grep -v none  | egrep -ve '^#'`
  if [[ -z "$connectto" ]] ; then
     echo "Unable to determine the connect parameter in the $sconf"
     echo "  We can not proceed with the automated correction of this parameter."
     echo "  You need to do this manually"
     echo "  exiting...."
     exit
  fi
  hostinconnecto=`echo $connectto | cut -f3 -d"@" |  cut -f1 -d":"`
  if [[ -z "$hostinconnecto" ]] ; then
     echo "Unable to determine the connect host value in the $sconf"
     echo "  We can not proceed with the automated correction of this parameter."
     echo "  You need to do this manually"
     echo "  exiting...."
     exit
  fi
  changeneeded=false
  if [[ "$hostinconnecto" = "$sloghost" ]] ; then
    echo "The host value in $sconf is correcly set to $hostinconnecto."
    #echo "  No changes are needed."
    #echo "  exiting...."
    #exit
  else
    echo "The host value in $sconf is not set to $sloghost."
    echo " It is currenlty set to $hostinconnecto"
    echo " Changing this value now from $hostinconnecto to $sloghost."
    changeneeded=true
    changehost=true
  fi
  
  isactionsendthere=`grep ActionSendTCPRebindInterval  $sconf | egrep -v  "^#" `
  if [[ -z "$isactionsendthere" ]] ; then
     echo "The ActionSendTCPRebindInterval value in $sconf is incorrect."
    echo " It is currenlty not set."
    echo " Changing this value now."
    changeneeded=true
    changerebind=true
  else 
    echo "The ActionSendTCPRebindInterval is set correctly."
  fi 

  #ActionSendStreamDriverAuthMode  x509/name
  isauthmodesetwrong=`grep '$ActionSendStreamDriverAuthMode.*x509*' $sconf | egrep -v  "^#" `
  if [[ -n "$isauthmodesetwrong" ]] ; then
    echo "The ActionSendStreamDriverAuthMode  value in $sconf is incorrect."
    echo " It is currenlty set to $isauthmodesetwrong"
    echo ' Changing this value now to $ActionSendStreamDriverAuthMode anon.'
    changeneeded=true
    changeauthmode=true
  else 
   echo "The ActionSendStreamDriverAuthMode  value is set correctly."
  fi

  # $ActionSendStreamDriverPermittedPeer *.vzwnet.com
  ispeersetwrong=`grep '$ActionSendStreamDriverPermittedPeer' $sconf | egrep -v  "^#" `
  if [[ -n "$ispeersetwrong" ]] ; then
    echo "The ActionSendStreamDriverPermittedPeer value in $sconf is incorrect."
    echo " It is currenlty set to $ispeersetwrong"
    echo ' Removing this value now.'
    changeneeded=true
    changepeer=true
  else
    echo "The ActionSendStreamDriverPermittedPeer value is set correctly."
  fi 

  if [[ "$changeneeded" == "true" ]] ; then
    backupfile=$sconf-`date +%T_%Y`
    cp $sconf $backupfile
    if [[ !  -f "$backupfile" ]] ; then
      echo "Unable to make a backup copy of the $sconf file"
      echo "  The copy of $sconf to $backupfile failed"
      echo "  This script has failed: exiting"
      exit
     else
      echo "A backup of $sconf was made as $backupfile"

    fi

    tmpfile=/tmp/rsyslog.conf.tmp.0
    cat  $sconf  > $tmpfile.0
    if [[ ! -f $tmpfile.0 ]] ; then
      echo "Unable to make a temp working file $tmpfile.0"
      echo "  This script has failed: exiting"
      exit
    fi
    let a=0
    let b=1
    if [[ "$changehost" == "true" ]] ; then
      sed "s/$hostinconnecto:10514/$sloghost:10514/g" $tmpfile.$a > $tmpfile.$b
      isthere=`grep $sloghost $tmpfile.$b | egrep -v  "^#"`
      if [[ -z "$isthere" ]] ; then
        echo "Unable to created $tmpfile.$b does not containt $sloghost"
        echo "  This script has failed: exiting"
        exit
      fi
      let a=a+1
      let b=b+1
    fi 

    if [[ "$changerebind" == "true" ]] ; then
      cat $tmpfile.$a | \
awk '
{
if ( $0 !~ /^\$ActionFileDefaultTemplate.*/ )
  {
   print $0
  }
else
  {
  print "$ActionFileDefaultTemplate RSYSLOG_TraditionalFileFormat"
  print "$ActionSendTCPRebindInterval 10000" 
  }
}
'  > $tmpfile.$b
      isthere=`grep ActionSendTCPRebindInterval  $tmpfile.$b | egrep -v  "^#"`
      if [[ -z "$isthere" ]] ; then
        echo "Unable to created $tmpfile.$b does not containt ActionSendTCPRebindInterval"
        echo "  This script has failed: exiting"
        exit
      fi
      let a=a+1
      let b=b+1
    fi


    if [[ "$changeauthmode" == "true" ]] ; then
      cat $tmpfile.$a | \
awk '
{
if ( $0 !~ /^\$ActionSendStreamDriverAuthMode.*/  )
  {
   print $0
  }
else 
  {
  print "$ActionSendStreamDriverAuthMode anon"
  }
}
'  > $tmpfile.$b
      isthere=`grep 'ActionSendStreamDriverAuthMode.*anon'  $tmpfile.$b | egrep -v  "^#"`
      if [[ -z "$isthere" ]] ; then
        echo "Unable to created $tmpfile.$b does not containt ActionSendStreamDriverAuthMode anon"
        echo "  This script has failed: exiting"
        exit
      fi
      let a=a+1
      let b=b+1
    fi

    if [[ "$changepeer" == "true" ]] ; then
      cat $tmpfile.$a | \
awk '
{
if ( $0 !~ /^\$ActionSendStreamDriverPermittedPeer.*/ )
  {
   print $0
  }
else 
  {
  print "#$ActionSendStreamDriverPermittedPeer *.vzwnet.com"
  }
}
'  > $tmpfile.$b
      isthere=`grep '$ActionSendStreamDriverPermittedPeer.*'  $tmpfile.$b | egrep  "^#"`
      if [[ -z "$isthere" ]] ; then
        echo "Unable to created $tmpfile.$b does not containt the commented out ActionSendStreamDriverPermittedPeer"
        echo "  This script has failed: exiting"
        exit
      fi
      let a=a+1
      let b=b+1
    fi


    cp $tmpfile.$a $sconf
    diff $tmpfile.$a $sconf  2>&1 >/dev/null
    RETURN_CODE=$?
    if (( $RETURN_CODE>0 )) ; then
      echo "The $tmpfile.$a file is not the same as $sconf"
      echo "  The copy of $tmpfile to $sconf failed"
      echo "  This script has failed: exiting"
      exit
    else
      echo "The new $sconf has been installed"
      echo "restarting rsyslogd"
      if [[ $OS = "SunOS" ]] ; then
        if [[ "$release" = "5.11"   ]] ; then
          servicename=svc:/system/system-log:rsyslog
          svcadm restart    svc:/system/system-log:rsyslog
        elif [[ "$release" = "5.10" ]] ; then
          servicename=svc:/network/cswrsyslog:default
        else
          echo "The $release of Solaris is not supported by this script."
          echo "  This script has failed: exiting"
          exit
        fi
        svcadm restart $servicename
        echo "  sleeping 1"
        sleep 1
        echo "  running svcs $servicename"
        svcs $servicename
        isonlines=`svcs $servicename | grep online`
      if [[ -n "$isonlines" ]] ; then
        echo "  Successful completion"
        #exit
      else
        echo "  The rsyslog service is not online."
        echo "  This script has failed: exiting"
        exit
      fi
      elif [[ $OS = "Linux" ]] ; then
        release=`/bin/uname -r`
        if [[ -n $release ]] ; then
          release=`echo $release | awk -F"." '{print $1"."$2}'`
        fi
        if [[ $release = "2.7" ]] ; then
          systemctl restart rsyslog
        else 
          service rsyslog restart
        fi    
        logger -p local5.info test
    fi
cat <<EOF
   Please check the following
     /var/log/syslog to ensure that rsyslog is was able to read the config file
   
     logger -p local5.info test
     netstat -an | grep 10514    to validate that a connection is up to the $sloghost

EOF
    fi
   else
     echo "No change was needed."
  fi
fi 


#

#EOF
