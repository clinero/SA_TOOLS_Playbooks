#!/bin/bash

##
## postcheck
##
## this is an attempt to find local accounts that
## have conficting and missing LDAP values
##
## The LDAP database is our database of record for account
## attribute values
##
##

if [[ -n $BASH ]] ; then 
  shellgame=`basename $BASH`  
fi

if [[ $shellgame != bash ]] ; then
  echo "this only can be ran on system with bash"
  echo bailing
  exit
fi 


OS=`/bin/uname -s`


currentns=`grep passwd /etc/nsswitch.conf |  grep -v \^\#`


listcontains() {
  for word in $1; do
    [[ $word = $2 ]] && return 0
  done
  return 1
}


if [ $OS = "Linux" ]; then
  ID=/usr/bin/id
else
  ID=/usr/xpg4/bin/id

fi

if [ `$ID -u` != 0 ]; then
  echo This can only be ran by a root account
  echo bagging it
  exit
fi

if [ $OS = "Linux" ]; then
  blessedusers="root patrol bin daemon adm lp sync shutdown halt mail news uucp operator games gopher ftp nobody nscd distcache vcsa ntp logadm mightor logcp stdsmont" 
else

   blessedusers="patrol bin root daemon daemon sys adm lp uucp nuucp listen gdm webservd svctag unknown nobody noaccess nobody4 plitent smmsp stdsaudi mightor sshd logadm" 
fi


base="ou=profile,dc=vzwnet,dc=com"
account="cn=vzwnet-proxyagent,ou=profile,dc=vzwnet,dc=com"
ProxyPassword='jamba!juice'


getuid ()
{ #get base upon the name 
server=$1
uid=$2
base="ou=people,dc=vzwnet,dc=com"
sout=`ldapsearch -h $server -D "$account" -w "$ProxyPassword" -b$base -T -s sub "(uid=$uid)" uid | grep -v dn:`
RETURN_CODE=$?
if [[ -z $sout ]] ; then 
  echo none
else
  suid=`echo $sout |awk '{if ($3=="uid:") {print $4}}'`
  if [[ -z $suid ]] ; then 
     suid=`echo $sout |awk '{if ($1=="uid:") {print $2}}'`
  fi
  if [[ -n $suid ]] ; then
     echo $suid
  else
     echo failed

  fi
fi
}

getuidnumfromname ()
{ #get base upon the name
server=$1
uid=$2
base="ou=people,dc=vzwnet,dc=com"
sout=`ldapsearch -h $server -D "$account" -w "$ProxyPassword" -b$base -T -s sub "(uid=$uid)" uidNumber | grep -v dn:`
RETURN_CODE=$?
if [[ -z $sout ]] ; then
  echo none
else
  suidnumber=`echo $sout |awk '{if ($3=="uidNumber:") {print $4}}'`
  if [[ -z $suidnumber ]] ; then
     suidnumber=`echo $sout |awk '{if ($1=="uidNumber:") {print $2}}'`
  fi
  if [[ -n $suidnumber ]] ; then
     echo $suidnumber
  else
     echo failed

  fi
fi
}



getuidnum ()
{ #get the uid from a supplied uidnumber
server=$1
uidnum=$2
base="ou=people,dc=vzwnet,dc=com"
sout=`ldapsearch -h $server -D "$account" -w "$ProxyPassword" -b$base -T -s sub "(uidNumber=$uidnum)" uid | grep -v dn:`
RETURN_CODE=$?
if [[ -z $sout ]] ; then
  echo none
else
  suid=`echo $sout |awk '{if ($3=="uid:") {print $4}}'`
  if [[ -z $suid ]] ; then
     suid=`echo $sout |awk '{if ($1=="uid:") {print $2}}'`
  fi
  if [[ -n $suid ]] ; then
     echo $suid
  else
     echo failed
  fi
fi
}





 
checkldapservice ()
{
server=$1
if [ -z "$server" ] ; then
  return 2
fi

#count=`ldapsearch  -h $server -D $account -w "$ProxyPassword" -b$base  -T -s sub "(objectclass=*)" 2>&1 | grep defaultSearchBase: | wc -l`
count=`ldapsearch  -h $server -D $account -w "$ProxyPassword" -b$base  -T "(objectclass=*)" 2>&1 | grep defaultSearchBase: | wc -l`

RETURN_CODE=$?
if (( $RETURN_CODE>0 )) ; then
  return 2
fi

if [ -z "$count" ] ; then
  return 2
fi

if (( $count<1 )) ; then
  return 1
fi
return 0
}

getldapserver ()

{
ldapservers='njbbldapp17 txslldap11 caroldapp10'

  echo seeking an LDAP server

  for server in $ldapservers
   do
   alive=`$PING $server 4 2>&1 | grep alive`
   if [ -n "$alive" ] ; then
     server=""
     continue
   else
     break
   fi
   done

  if [ -z "$server" ] ; then
    echo "We were not able to contract an LDAP server at this time"
    echo "this script can not continue"
    exit
  fi

  checkldapservice $server
  echo "Selected $server to use for the ldap account overlap check"

  FunctionCode=$?

  if (( ($FunctionCode)>0 )) ; then
    echo "we were unable to establish a ldap connection to $server at this time"
    echo "this script can not continue"
    exit
  fi

  echo "we were able to query the ldap service on $server"
}



for i in ` egrep  -v  '\*LK' /etc/shadow | egrep -v ':NP:'| grep -v \^\# | awk '{print $1}'`
do
  #echo "=>$i"
  tuser=`echo $i | cut -f1 -d":"`
  #tgid=`echo $i | cut -f4 -d":"`
  #echo $i
  if (listcontains  "$blessedusers" $tuser ) ; then 
    #echo skipping $tuser 
    continue
  fi

  echo "#    notice: local account $tuser is not a standard local user execute:"
  echo "passwd -N $tuser"
done


